import {
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";

export const restaurantOrders = pgTable("restaurant_orders", {
  id: serial("id").primaryKey(),
  receiptNumber: varchar("receipt_number", { length: 32 }).notNull().unique(),
  cashier: varchar("cashier", { length: 100 }).notNull(),
  orderType: varchar("order_type", { length: 20 }).notNull(),
  tableLabel: varchar("table_label", { length: 40 }),
  customerName: varchar("customer_name", { length: 120 }),
  paymentMethod: varchar("payment_method", { length: 24 }).notNull(),
  subtotal: integer("subtotal").notNull(),
  discount: integer("discount").notNull().default(0),
  total: integer("total").notNull(),
  notes: text("notes"),
  status: varchar("status", { length: 24 }).notNull().default("paid"),
  createdAt: timestamp("created_at", { withTimezone: true, mode: "date" })
    .defaultNow()
    .notNull(),
});

export const restaurantOrderItems = pgTable("restaurant_order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id")
    .notNull()
    .references(() => restaurantOrders.id, { onDelete: "cascade" }),
  productId: varchar("product_id", { length: 64 }).notNull(),
  name: varchar("name", { length: 140 }).notNull(),
  quantity: integer("quantity").notNull(),
  unitPrice: integer("unit_price").notNull(),
  lineTotal: integer("line_total").notNull(),
});
