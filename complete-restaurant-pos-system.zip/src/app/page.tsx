"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useState, type ReactNode } from "react";
import { DishImage, RestaurantLogo, setRestaurantFavicon } from "@/components/dish-image";
import { formatDateTime, formatMoney, formatNumber, NUMBER_LOCALE } from "@/lib/format";
import {
  createOrder,
  DEFAULT_SETTINGS,
  ensureLocalStore,
  readSnapshot,
  subscribeToDataChanges,
  verifyUser,
  type DataSnapshot,
  type RestaurantOrder,
  type RestaurantUser,
} from "@/lib/local-store";
import type { MenuProduct } from "@/lib/menu";

type PaymentMethod = RestaurantOrder["paymentMethod"];
type OrderType = RestaurantOrder["orderType"];
type Screen = "pos" | "orders";

type IconProps = { name: string; size?: number; className?: string };
function Icon({ name, size = 20, className }: IconProps) {
  let shape: ReactNode;
  switch (name) {
    case "brand": shape = <><path d="M4 13.5h16a8 8 0 0 1-16 0Z" /><path d="M7 9.5a5 5 0 0 1 10 0M12 3v2M4 20h16" /></>; break;
    case "grid": shape = <><rect x="3.5" y="3.5" width="7" height="7" rx="1.6" /><rect x="13.5" y="3.5" width="7" height="7" rx="1.6" /><rect x="3.5" y="13.5" width="7" height="7" rx="1.6" /><rect x="13.5" y="13.5" width="7" height="7" rx="1.6" /></>; break;
    case "receipt": shape = <><path d="M6 3.5h12v17l-3-1.8-3 1.8-3-1.8-3 1.8v-17Z" /><path d="M9 8h6M9 12h6M9 16h3" /></>; break;
    case "shield": shape = <><path d="m12 3 8 3v5.5c0 5-3.4 8.1-8 9.9-4.6-1.8-8-4.9-8-9.9V6l8-3Z" /><path d="m9 12 2 2 4-4" /></>; break;
    case "search": shape = <><circle cx="10.8" cy="10.8" r="6.8" /><path d="m16 16 4.2 4.2" /></>; break;
    case "bell": shape = <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9ZM10 21h4" /></>; break;
    case "clock": shape = <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3.5 2" /></>; break;
    case "plus": shape = <path d="M12 5v14M5 12h14" />; break;
    case "minus": shape = <path d="M5 12h14" />; break;
    case "close": shape = <path d="m6 6 12 12M18 6 6 18" />; break;
    case "trash": shape = <><path d="M4 7h16M10 11v6M14 11v6M5.5 7l1 13h11l1-13M9 7V4h6v3" /></>; break;
    case "table": shape = <><path d="M3 8h18M5 8v12M19 8v12M3 13h18M8 8V5h8v3" /></>; break;
    case "cash": shape = <><rect x="3" y="6" width="18" height="12" rx="2" /><circle cx="12" cy="12" r="2.5" /><path d="M6 9h.01M18 15h.01" /></>; break;
    case "card": shape = <><rect x="3" y="5" width="18" height="14" rx="2" /><path d="M3 10h18M7 15h3" /></>; break;
    case "wallet": shape = <><path d="M4 6.5A2.5 2.5 0 0 1 6.5 4H20v15H6a3 3 0 0 1-3-3V7a.5.5 0 0 1 .5-.5H20" /><path d="M20 10h-5a2 2 0 0 0 0 4h5M15 12h.01" /></>; break;
    case "user": shape = <><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>; break;
    case "check": shape = <path d="m5 12 4.3 4.3L19.5 6" />; break;
    case "print": shape = <><path d="M6 8V3h12v5M6 17H4a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-2" /><path d="M6 14h12v7H6zM18 11h.01" /></>; break;
    case "refresh": shape = <><path d="M20 7v5h-5M4 17v-5h5" /><path d="M5.6 9A7 7 0 0 1 18 6l2 2M4 16l2 2a7 7 0 0 0 12.4-3" /></>; break;
    case "bag": shape = <><path d="M5 8h14l1 13H4L5 8Z" /><path d="M9 9V6a3 3 0 0 1 6 0v3" /></>; break;
    case "arrow": shape = <><path d="M5 12h14M13 6l6 6-6 6" /></>; break;
    case "receiptSmall": shape = <><path d="M5 4h14v16l-3-2-3 2-3-2-3 2V4Z" /><path d="M8 8h8M8 12h5" /></>; break;
    case "note": shape = <><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z" /><path d="M14 2v6h6M8 13h8M8 17h8" /></>; break;
    default: shape = <circle cx="12" cy="12" r="8" />;
  }
  return <svg aria-hidden="true" className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">{shape}</svg>;
}

function paymentName(value: string) {
  if (value === "card") return "بطاقة";
  if (value === "wallet") return "محفظة";
  return "نقدي";
}
function orderTypeName(value: string) {
  if (value === "delivery") return "توصيل";
  if (value === "takeaway") return "سفري";
  return "صالة";
}

function OrdersView({ orders, cashier, onRefresh, onOpenReceipt }: { orders: RestaurantOrder[]; cashier: RestaurantUser | null; onRefresh: () => void; onOpenReceipt: (order: RestaurantOrder) => void }) {
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("all");
  const filteredOrders = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase();
    return orders.filter((order) => {
      const matchesStatus = status === "all" || order.status === status;
      const matchesCashier = cashier?.role === "manager" || order.cashierId === cashier?.id;
      const matchesQuery = !normalized || `${order.receiptNumber} ${order.customerName ?? ""} ${order.tableLabel ?? ""} ${order.cashier} ${order.items.map((item) => item.name).join(" ")}`.toLocaleLowerCase().includes(normalized);
      return matchesStatus && matchesCashier && matchesQuery;
    });
  }, [orders, query, status, cashier]);
  return (
    <section className="history-content" aria-label="الطلبات والفواتير">
      <div className="history-title-row"><div><h2>الطلبات والفواتير</h2></div><button className="secondary-button refresh-button" type="button" onClick={onRefresh}><Icon name="refresh" size={17} /> تحديث</button></div>
      <div className="history-toolbar"><label className="search-field history-search"><Icon name="search" size={18} /><input aria-label="بحث في الفواتير" placeholder="بحث برقم الفاتورة أو اسم العميل" value={query} onChange={(event) => setQuery(event.target.value)} /></label><select className="history-filter" aria-label="حالة الفاتورة" value={status} onChange={(event) => setStatus(event.target.value)}><option value="all">كل الفواتير</option><option value="paid">مدفوعة</option><option value="cancelled">ملغاة</option></select><span className="history-count"><Icon name="receiptSmall" size={16} /> {formatNumber(filteredOrders.length)} فاتورة</span></div>
      <div className="orders-table-wrap"><table className="orders-table"><thead><tr><th>رقم الفاتورة</th><th>العميل / الطاولة</th><th>الأصناف</th><th>طريقة الدفع</th><th>التوقيت</th><th>الصافي</th><th>الحالة</th><th /></tr></thead><tbody>{filteredOrders.length === 0 ? <tr><td className="table-message" colSpan={8}><div className="empty-history"><span className="empty-icon"><Icon name="receipt" size={24} /></span><strong>لا توجد فواتير</strong></div></td></tr> : filteredOrders.map((order) => <tr key={order.id} className={order.status === "cancelled" ? "cancelled-order-row" : ""}><td><span className="receipt-number">{order.receiptNumber}</span><small>{order.cashier}</small></td><td><strong>{order.customerName || orderTypeName(order.orderType)}</strong><small>{order.tableLabel || orderTypeName(order.orderType)}</small></td><td><span className="items-count">{formatNumber(order.items.reduce((sum, item) => sum + item.quantity, 0))} أصناف</span></td><td><span className="payment-chip">{paymentName(order.paymentMethod)}</span></td><td><span className="date-cell">{formatDateTime(order.createdAt)}</span></td><td><strong className="amount-cell">{formatMoney(order.total)}</strong></td><td><span className={`order-status ${order.status}`}>{order.status === "cancelled" ? "ملغاة" : "مدفوعة"}</span></td><td><button className="row-open-button" type="button" onClick={() => onOpenReceipt(order)} aria-label={`عرض الفاتورة ${order.receiptNumber}`}><Icon name="arrow" size={17} /></button></td></tr>)}</tbody></table></div>
      <div className="mobile-orders-list">{filteredOrders.length === 0 ? <div className="empty-history mobile-empty-history"><span className="empty-icon"><Icon name="receipt" size={23} /></span><strong>لا توجد فواتير</strong></div> : filteredOrders.map((order) => <button className={`mobile-order-card ${order.status === "cancelled" ? "cancelled" : ""}`} key={order.id} type="button" onClick={() => onOpenReceipt(order)}><span className="mobile-order-card-top"><strong>{order.receiptNumber}</strong><span className={`order-status ${order.status}`}>{order.status === "cancelled" ? "ملغاة" : "مدفوعة"}</span></span><span className="mobile-order-card-info"><span>{order.customerName || orderTypeName(order.orderType)} · {order.cashier}</span><span>{formatDateTime(order.createdAt)}</span></span><span className="mobile-order-card-bottom"><span>{formatNumber(order.items.reduce((sum, item) => sum + item.quantity, 0))} أصناف · {paymentName(order.paymentMethod)}</span><strong>{formatMoney(order.total)}</strong></span></button>)}</div>
    </section>
  );
}

function ReceiptModal({ order, settings, onClose }: { order: RestaurantOrder; settings: DataSnapshot["settings"]; onClose: () => void }) {
  const itemCount = order.items.reduce((sum, item) => sum + item.quantity, 0);
  return <div className="modal-backdrop receipt-backdrop" role="presentation" onMouseDown={onClose}><section className="receipt-modal" dir="rtl" role="dialog" aria-modal="true" aria-labelledby="receipt-title" onMouseDown={(event) => event.stopPropagation()}>
    <button className="modal-close" type="button" aria-label="إغلاق" onClick={onClose}><Icon name="close" size={19} /></button>
    <div className="receipt-brand-mark"><RestaurantLogo logo={settings.logo} name={settings.restaurantName} iconClass="receipt-logo-icon" size={25} /></div><span className="receipt-subtitle">{settings.restaurantName}</span>
    {settings.address && <span className="receipt-subtitle">{settings.address}</span>}
    {settings.phone && <span className="receipt-subtitle">{settings.phone}</span>}
    <h2 id="receipt-title">إيصال بيع</h2>
    <div className="receipt-id-row"><span>رقم الفاتورة</span><strong>{order.receiptNumber}</strong></div><div className="receipt-date-row"><span>{formatDateTime(order.createdAt)}</span><span>الكاشير: {order.cashier}</span></div>
    {order.status === "cancelled" && <div className="receipt-cancelled-notice">فاتورة ملغاة · {order.cancelReason}</div>}
    <div className="receipt-dashed" /><div className="receipt-items-heading"><span>الصنف × الكمية</span><span>السعر</span></div>
    <div className="receipt-items">{order.items.map((item, index) => <div className="receipt-item-row" key={`${item.productId}-${index}`}><span>{item.name} <small>× {formatNumber(item.quantity)}</small></span><strong>{formatMoney(item.lineTotal)}</strong></div>)}</div>
    <div className="receipt-dashed" /><div className="receipt-total-row"><span>المجموع الفرعي</span><span>{formatMoney(order.subtotal)}</span></div>
    {order.discount > 0 && <div className="receipt-total-row discount-line"><span>الخصم</span><span>− {formatMoney(order.discount)}</span></div>}
    <div className="receipt-total-row"><span>ضريبة القيمة المضافة ({formatNumber(settings.taxRate)}%)</span><span>{formatMoney(order.tax)}</span></div>
    {order.service > 0 && <div className="receipt-total-row"><span>الخدمة ({formatNumber(settings.serviceRate)}%)</span><span>{formatMoney(order.service)}</span></div>}
    {order.deliveryFee > 0 && <div className="receipt-total-row"><span>رسوم التوصيل</span><span>{formatMoney(order.deliveryFee)}</span></div>}
    <div className="receipt-total-row final-total"><strong>الصافي</strong><strong>{formatMoney(order.total)}</strong></div>
    {order.paymentMethod === "cash" && <><div className="receipt-total-row"><span>المبلغ المستلم</span><span>{formatMoney(order.cashReceived)}</span></div><div className="receipt-total-row"><span>الباقي</span><span>{formatMoney(order.changeDue)}</span></div></>}
    <div className="receipt-meta"><span>{orderTypeName(order.orderType)}{order.tableLabel ? ` · ${order.tableLabel}` : ""}</span><span>{paymentName(order.paymentMethod)}</span><span>{formatNumber(itemCount)} صنف</span></div>
    {order.notes && <p className="receipt-note">تعليق: {order.notes}</p>}
    {settings.taxNumber && <span className="receipt-tax-number">الرقم الضريبي: {settings.taxNumber}</span>}
    <p className="receipt-thanks">{settings.receiptMessage}</p>
    <div className="receipt-actions no-print"><button className="primary-button" type="button" onClick={() => window.print()}><Icon name="print" size={17} /> طباعة الإيصال</button><button className="secondary-button" type="button" onClick={onClose}>إغلاق</button></div>
  </section></div>;
}

function CashierLogin({ onLogin, restaurantName, logo }: { onLogin: (user: RestaurantUser) => void; restaurantName: string; logo: string }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (loading) return;
    setLoading(true);
    setError("");
    try {
      const user = await verifyUser(username, password);
      if (!user) throw new Error("اسم المستخدم أو كلمة المرور غير صحيحة");
      onLogin(user);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "تعذر تسجيل الدخول");
    } finally {
      setLoading(false);
    }
  }
  return <main className="cashier-login-page" dir="rtl"><form className="cashier-login-card" onSubmit={submit}><RestaurantLogo logo={logo} name={restaurantName} className="cashier-login-logo" /><span className="eyebrow">{restaurantName}</span><h1>دخول الكاشير</h1><label className="admin-login-label" htmlFor="cashier-name">اسم المستخدم</label><input id="cashier-name" className="cashier-login-input" autoComplete="username" value={username} onChange={(event) => setUsername(event.target.value)} required /><label className="admin-login-label" htmlFor="cashier-password">كلمة المرور</label><input id="cashier-password" className="cashier-login-input" type="password" autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} required />{error && <div className="admin-login-error" role="alert">{error}</div>}<button className="admin-login-submit" type="submit" disabled={loading}>{loading ? "جارٍ التحقق..." : "دخول"}</button><Link className="cashier-admin-link" href="/admin">دخول الإدارة</Link></form></main>;
}

export default function HomePage() {
  const [screen, setScreen] = useState<Screen>("pos");
  const [snapshot, setSnapshot] = useState<DataSnapshot | null>(null);
  const [loadError, setLoadError] = useState("");
  const [cashier, setCashier] = useState<RestaurantUser | null>(null);
  const [cart, setCart] = useState<Record<string, number>>({});
  const [category, setCategory] = useState("الكل");
  const [search, setSearch] = useState("");
  const [orderType, setOrderType] = useState<OrderType>("dine-in");
  const [tableLabel, setTableLabel] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [notes, setNotes] = useState("");
  const [discountInput, setDiscountInput] = useState("0");
  const [cashInput, setCashInput] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("cash");
  const [submitting, setSubmitting] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [receipt, setReceipt] = useState<RestaurantOrder | null>(null);
  const [toast, setToast] = useState("");
  const [now, setNow] = useState<Date | null>(null);

  const reload = useCallback(async () => {
    try {
      await ensureLocalStore();
      const value = await readSnapshot();
      setSnapshot(value);
      setLoadError("");
    } catch (error) {
      setLoadError(error instanceof Error ? error.message : "تعذر فتح بيانات النظام");
    }
  }, []);
  const showToast = useCallback((message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 3000);
  }, []);

  useEffect(() => {
    setNow(new Date());
    void reload();
    const unsubscribe = subscribeToDataChanges(() => void reload());
    const timer = window.setInterval(() => setNow(new Date()), 30_000);
    return () => { unsubscribe(); window.clearInterval(timer); };
  }, [reload]);

  const products = useMemo(() => (snapshot?.products ?? []).filter((product) => product.active !== false), [snapshot]);
  const categories = useMemo(() => snapshot?.categories ?? [], [snapshot]);
  const orders = snapshot?.orders ?? [];
  const settings = snapshot?.settings ?? DEFAULT_SETTINGS;
  const tables = snapshot?.tables.filter((table) => table.active) ?? [];
  const activeCategory = category !== "الكل" && !categories.some((item) => item.name === category) ? "الكل" : category;
  const cartLines = useMemo(() => products.flatMap((product) => cart[product.id] ? [{ product, quantity: cart[product.id] }] : []), [cart, products]);
  const itemCount = cartLines.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = cartLines.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const discount = Math.min(subtotal, Math.max(0, Math.floor(Number(discountInput) || 0)));
  const taxable = subtotal - discount;
  const tax = Math.round(taxable * Math.max(0, settings?.taxRate ?? 14) / 100);
  const service = orderType === "dine-in" ? Math.round(taxable * Math.max(0, settings?.serviceRate ?? 12) / 100) : 0;
  const deliveryFee = orderType === "delivery" ? Math.max(0, settings?.deliveryFee ?? 35) : 0;
  const total = taxable + tax + service + deliveryFee;
  const cashReceived = cashInput === "" ? total : Math.max(0, Number(cashInput) || 0);
  const changeDue = Math.max(0, cashReceived - total);

  const visibleProducts = useMemo(() => {
    const normalized = search.trim().toLocaleLowerCase();
    return products.filter((product) => {
      const matchesCategory = activeCategory === "الكل" || product.category === activeCategory;
      const matchesSearch = !normalized || `${product.name} ${product.description} ${product.category}`.toLocaleLowerCase().includes(normalized);
      return matchesCategory && matchesSearch;
    });
  }, [products, activeCategory, search]);

  useEffect(() => { setRestaurantFavicon(settings.logo, settings.restaurantName); }, [settings.logo, settings.restaurantName]);

  function adjustItem(product: MenuProduct, amount: number) {
    setCart((current) => {
      const next = { ...current };
      const quantity = (next[product.id] ?? 0) + amount;
      if (quantity < 1) delete next[product.id];
      else next[product.id] = Math.min(quantity, 99);
      return next;
    });
  }

  async function completeOrder() {
    if (!cashier || cartLines.length === 0 || submitting) return;
    if (paymentMethod === "cash" && cashReceived < total) { showToast("المبلغ المستلم أقل من الصافي"); return; }
    setSubmitting(true);
    try {
      const saved = await createOrder({
        items: cartLines.map(({ product, quantity }) => ({ productId: product.id, quantity })),
        cashier,
        orderType,
        tableLabel,
        customerName,
        notes,
        discount,
        cashReceived,
        paymentMethod,
      });
      setCart({});
      setDiscountInput("0");
      setCashInput("");
      setCustomerName("");
      setNotes("");
      setIsCartOpen(false);
      setReceipt(saved);
      showToast("تم حفظ الفاتورة");
      await reload();
    } catch (error) {
      showToast(error instanceof Error ? error.message : "تعذر حفظ الفاتورة");
    } finally {
      setSubmitting(false);
    }
  }

  const dateLabel = now ? new Intl.DateTimeFormat(NUMBER_LOCALE, { weekday: "long", day: "2-digit", month: "2-digit", year: "numeric" }).format(now) : "—";
  const timeLabel = now ? new Intl.DateTimeFormat(NUMBER_LOCALE, { hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).format(now) : "—";

  if (!snapshot) return <main className="store-loading" dir="rtl">{loadError ? <><strong>تعذر فتح النظام</strong><button type="button" onClick={() => void reload()}>إعادة المحاولة</button><small>{loadError}</small></> : <span className="button-spinner dark-spinner" />}</main>;
  if (!cashier) return <CashierLogin onLogin={setCashier} restaurantName={settings?.restaurantName ?? "مذاق البلد"} logo={settings?.logo ?? ""} />;

  return <div className="pos-shell" dir="rtl">
    <aside className="side-nav"><Link className="nav-brand" href="/" aria-label={settings?.restaurantName ?? "مذاق البلد"}><RestaurantLogo logo={settings?.logo} name={settings?.restaurantName ?? "مذاق البلد"} /></Link><div className="nav-items">
      <button className={`nav-button ${screen === "pos" ? "active" : ""}`} type="button" onClick={() => setScreen("pos")} title="الكاشير"><Icon name="grid" size={21} /><span>الكاشير</span></button>
      <button className={`nav-button ${screen === "orders" ? "active" : ""}`} type="button" onClick={() => setScreen("orders")} title="الطلبات"><span className="nav-icon-wrap"><Icon name="receipt" size={21} />{orders.length > 0 && <i className="nav-notice-dot" />}</span><span>الطلبات</span></button>
      <Link className="nav-button" href="/admin" title="الإدارة"><Icon name="shield" size={21} /><span>الإدارة</span></Link>
    </div><div className="nav-bottom"><div className="cashier-avatar">{cashier.name.slice(0, 1)}</div><span className="nav-cashier-name">{cashier.name}</span><span className="cashier-status" title="الوردية مفتوحة" /></div></aside>

    <main className="main-column"><header className="topbar"><div className="topbar-brand"><RestaurantLogo logo={settings?.logo} name={settings?.restaurantName ?? "مذاق البلد"} iconClass="topbar-mark" size={20} /><div><strong>{settings?.restaurantName ?? "مذاق البلد"}</strong><span>نظام نقاط البيع</span></div></div><div className="topbar-context"><span className="live-indicator"><i /> الوردية مفتوحة</span><span className="topbar-divider" /><span className="topbar-cashier"><span className="tiny-avatar">{cashier.name.slice(0, 1)}</span> {cashier.name}</span></div><div className="topbar-tools"><div className="date-display"><Icon name="clock" size={17} /><span>{dateLabel}</span><b>{timeLabel}</b></div><button className="topbar-icon-button" type="button" aria-label="تسجيل الخروج" onClick={() => { setCart({}); setCashier(null); }}><Icon name="user" size={18} /></button></div></header>

      {screen === "pos" ? <div className="catalog-content">
        <div className="page-heading-row"><div><h1>نقطة البيع</h1></div><div className="today-orders-pill"><span className="today-orders-icon"><Icon name="receiptSmall" size={18} /></span><span><small>الفواتير</small><strong>{formatNumber(orders.length)}</strong></span></div></div>
        <section className="promo-banner" aria-label={settings?.restaurantName ?? "مطعم"}><div className="promo-photo"><DishImage src={products[0]?.image ?? ""} name={settings?.restaurantName ?? "مطعم"} className="promo-image" sizes="(max-width: 700px) 100vw, 44vw" /></div><div className="promo-shade" /><div className="promo-content"><span className="promo-kicker"><Icon name="receiptSmall" size={14} /> {settings?.restaurantName}</span><h2>طلبات صالة · سفري · توصيل</h2><span className="promo-open"><i /> الوردية مفتوحة</span></div></section>
        <section className="menu-section" aria-label="منيو المطعم"><div className="menu-section-heading"><div><h2>منيو المطعم</h2></div><label className="search-field menu-search"><Icon name="search" size={18} /><input aria-label="بحث في المنيو" placeholder="ابحث عن صنف" value={search} onChange={(event) => setSearch(event.target.value)} />{search && <button type="button" className="clear-search" onClick={() => setSearch("")} aria-label="مسح البحث"><Icon name="close" size={15} /></button>}</label></div>
          <div className="category-scroller" role="tablist" aria-label="الأقسام"><button className={`category-chip ${activeCategory === "الكل" ? "selected" : ""}`} type="button" role="tab" aria-selected={activeCategory === "الكل"} onClick={() => setCategory("الكل")}>الكل<span>{formatNumber(products.length)}</span></button>{categories.map((item) => <button key={item.id} className={`category-chip ${activeCategory === item.name ? "selected" : ""}`} type="button" role="tab" aria-selected={activeCategory === item.name} onClick={() => setCategory(item.name)}>{item.name}<span>{formatNumber(products.filter((product) => product.category === item.name).length)}</span></button>)}</div>
          <div className="products-grid">{visibleProducts.map((product) => <button className="product-card" key={product.id} type="button" onClick={() => adjustItem(product, 1)} aria-label={`إضافة ${product.name} للسلة`}><div className="product-image-wrap"><DishImage src={product.image} name={product.name} className="product-image" />{product.badge && <span className={`product-badge ${product.badge === "جديد" ? "badge-new" : ""}`}>{product.badge}</span>}<span className="product-add"><Icon name="plus" size={18} /></span>{!!cart[product.id] && <span className="product-quantity">{formatNumber(cart[product.id])}</span>}</div><div className="product-details"><span className="product-category-label">{product.category}</span><strong className="product-name">{product.name}</strong><span className="product-description">{product.description}</span><div className="product-price-row"><strong>{formatMoney(product.price)}</strong><span>إضافة <Icon name="plus" size={13} /></span></div></div></button>)}</div>
          {visibleProducts.length === 0 && <div className="no-products"><span className="empty-icon"><Icon name="search" size={24} /></span><strong>لا توجد أصناف مطابقة</strong></div>}
        </section>
      </div> : <OrdersView orders={orders} cashier={cashier} onRefresh={() => void reload()} onOpenReceipt={setReceipt} />}
    </main>

    {screen === "pos" && <aside className={`order-panel ${isCartOpen ? "cart-open" : ""}`} aria-label="تفاصيل الطلب"><div className="order-header"><div><span className="eyebrow">{cashier.name}</span><h2>فاتورة جديدة <span>{formatNumber(itemCount)}</span></h2></div><button className="order-close-mobile" type="button" aria-label="إغلاق السلة" onClick={() => setIsCartOpen(false)}><Icon name="close" size={19} /></button><button className="new-order-button" type="button" aria-label="تفريغ الطلب" title="تفريغ الطلب" disabled={cartLines.length === 0} onClick={() => { if (window.confirm("تفريغ الفاتورة الحالية؟")) { setCart({}); setDiscountInput("0"); setCashInput(""); } }}><Icon name="trash" size={17} /></button></div>
      <div className="order-type-switch" role="group" aria-label="نوع الطلب"><button className={orderType === "dine-in" ? "selected" : ""} type="button" onClick={() => setOrderType("dine-in")}><Icon name="table" size={17} /> صالة</button><button className={orderType === "takeaway" ? "selected" : ""} type="button" onClick={() => setOrderType("takeaway")}><Icon name="bag" size={17} /> سفري</button><button className={orderType === "delivery" ? "selected" : ""} type="button" onClick={() => setOrderType("delivery")}><Icon name="arrow" size={17} /> توصيل</button></div>
      <div className="order-lines-scroll">{cartLines.length === 0 ? <div className="cart-empty"><span className="cart-empty-icon"><Icon name="bag" size={26} /></span><strong>الفاتورة فارغة</strong><span>ابدأ طلب جديد باختيار صنف.</span></div> : <div className="cart-lines">{cartLines.map(({ product, quantity }) => <div className="cart-line" key={product.id}><div className="cart-line-image"><DishImage src={product.image} name={product.name} /></div><div className="cart-line-main"><strong>{product.name}</strong><small>{formatMoney(product.price)} / قطعة</small><div className="quantity-stepper"><button type="button" aria-label={`تقليل ${product.name}`} onClick={() => adjustItem(product, -1)}><Icon name={quantity === 1 ? "trash" : "minus"} size={14} /></button><span>{formatNumber(quantity)}</span><button type="button" aria-label={`زيادة ${product.name}`} onClick={() => adjustItem(product, 1)}><Icon name="plus" size={14} /></button></div></div><strong className="cart-line-total">{formatMoney(product.price * quantity)}</strong></div>)}</div>}</div>
      <div className="order-details-form"><div className="customer-fields">{orderType === "dine-in" && <label className="compact-input"><Icon name="table" size={16} /><select value={tableLabel} onChange={(event) => setTableLabel(event.target.value)} aria-label="الطاولة"><option value="">اختر طاولة</option>{tables.map((table) => <option key={table.id} value={table.name}>{table.name}</option>)}</select></label>}<label className="compact-input"><Icon name="user" size={16} /><input value={customerName} onChange={(event) => setCustomerName(event.target.value)} placeholder="اسم العميل" aria-label="اسم العميل" /></label></div><label className="compact-input note-input"><Icon name="note" size={16} /><input value={notes} onChange={(event) => setNotes(event.target.value)} placeholder="تعليق" aria-label="تعليق" /></label>
        <div className="payment-label-row"><span>طريقة التحصيل</span><span className="payment-secure"><Icon name="shield" size={13} /> {cashier.name}</span></div><div className="payment-options" role="group" aria-label="طريقة الدفع"><button className={paymentMethod === "cash" ? "selected" : ""} type="button" onClick={() => setPaymentMethod("cash")}><Icon name="cash" size={17} /> نقدي</button><button className={paymentMethod === "card" ? "selected" : ""} type="button" onClick={() => setPaymentMethod("card")}><Icon name="card" size={17} /> بطاقة</button><button className={paymentMethod === "wallet" ? "selected" : ""} type="button" onClick={() => setPaymentMethod("wallet")}><Icon name="wallet" size={17} /> محفظة</button></div>
      </div>
      <div className="order-total-area"><div className="summary-row"><span>المجموع الفرعي <small>({formatNumber(itemCount)} قطعة)</small></span><strong>{formatMoney(subtotal)}</strong></div><label className="discount-row"><span>الخصم</span><span className="discount-input-wrap"><input aria-label="قيمة الخصم" type="number" min="0" max={subtotal} step="1" value={discountInput} onChange={(event) => setDiscountInput(event.target.value)} /><small>ج.م</small></span></label>
        <div className="summary-row financial-line"><span>الضريبة ({formatNumber(settings.taxRate)}%)</span><strong>{formatMoney(tax)}</strong></div>{service > 0 && <div className="summary-row financial-line"><span>الخدمة ({formatNumber(settings.serviceRate)}%)</span><strong>{formatMoney(service)}</strong></div>}{deliveryFee > 0 && <div className="summary-row financial-line"><span>رسوم التوصيل</span><strong>{formatMoney(deliveryFee)}</strong></div>}
        {paymentMethod === "cash" && itemCount > 0 && <label className="cash-received-row"><span>المبلغ المستلم</span><input aria-label="المبلغ المستلم" type="number" min={total} step="1" placeholder={String(total)} value={cashInput} onChange={(event) => setCashInput(event.target.value)} /></label>}
        <div className="total-divider" /><div className="final-total-row"><div><span>الصافي</span><small>بعد الضريبة والخدمة</small></div><strong>{formatMoney(total)}</strong></div>{paymentMethod === "cash" && cashReceived > total && <div className="change-row"><span>الباقي</span><strong>{formatMoney(changeDue)}</strong></div>}
        <button className="checkout-button" type="button" disabled={itemCount === 0 || submitting} onClick={() => void completeOrder()}>{submitting ? <span className="button-spinner" /> : <Icon name="check" size={19} />}<span>{submitting ? "جارٍ الحفظ..." : "تحصيل وحفظ الفاتورة"}</span>{!submitting && <strong>{formatMoney(total)}</strong>}</button>
      </div>
    </aside>}

    {screen === "pos" && isCartOpen && <button className="cart-scrim" type="button" aria-label="إغلاق تفاصيل الطلب" onClick={() => setIsCartOpen(false)} />}
    {screen === "pos" && <button className="mobile-cart-button" type="button" onClick={() => setIsCartOpen(true)}><span className="mobile-cart-count">{formatNumber(itemCount)}</span><span><strong>عرض الفاتورة</strong><small>{itemCount === 0 ? "ابدأ طلب جديد" : `${formatNumber(itemCount)} صنف`}</small></span><b>{formatMoney(total)}</b><Icon name="arrow" size={18} /></button>}
    {toast && <div className="toast-message" role="status"><span><Icon name="check" size={16} /></span>{toast}</div>}
    {receipt && <ReceiptModal order={receipt} settings={settings} onClose={() => setReceipt(null)} />}
  </div>;
}
