"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";
import { DishImage, RestaurantLogo, setRestaurantFavicon } from "@/components/dish-image";
import { formatDate, formatDateTime, formatMoney, formatNumber, toIsoDate } from "@/lib/format";
import {
  cancelOrder,
  changeOwnPassword,
  compressImageFile,
  deleteCategory,
  deleteProduct,
  deleteTable,
  deleteUser,
  exportDataBackup,
  hashNewPassword,
  importDataBackup,
  readSnapshot,
  renameCategory,
  reorderCategories,
  resetAllData,
  saveCategory,
  saveProduct,
  saveSettings,
  saveTable,
  saveUser,
  subscribeToDataChanges,
  verifyUser,
  type DataSnapshot,
  type RestaurantCategory,
  type RestaurantOrder,
  type RestaurantSettings,
  type RestaurantTable,
  type RestaurantUser,
  type UserRole,
} from "@/lib/local-store";
import type { MenuProduct } from "@/lib/menu";

type TabId = "overview" | "products" | "categories" | "tables" | "invoices" | "reports" | "users" | "settings" | "backup";
type ProductDraft = { id: string; name: string; description: string; category: string; price: string; image: string; badge: string; active: boolean };
type UserDraft = { id: string; name: string; username: string; role: UserRole; password: string; active: boolean };

const tabs: { id: TabId; label: string; icon: string }[] = [
  { id: "overview", label: "الرئيسية", icon: "overview" },
  { id: "products", label: "الأصناف", icon: "products" },
  { id: "categories", label: "الأقسام", icon: "categories" },
  { id: "tables", label: "الطاولات", icon: "tables" },
  { id: "invoices", label: "الفواتير", icon: "orders" },
  { id: "reports", label: "التقارير", icon: "reports" },
  { id: "users", label: "المستخدمون", icon: "users" },
  { id: "settings", label: "الإعدادات", icon: "settings" },
  { id: "backup", label: "النسخ الاحتياطي", icon: "backup" },
];

function AdminIcon({ name, size = 18 }: { name: string; size?: number }) {
  let shape: ReactNode;
  switch (name) {
    case "brand": shape = <><path d="M4 13.5h16a8 8 0 0 1-16 0Z"/><path d="M7 9.5a5 5 0 0 1 10 0M12 3v2M4 20h16"/></>; break;
    case "overview": shape = <><path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7h-6v7H4a1 1 0 0 1-1-1V10Z"/><path d="M9 21v-7h6v7"/></>; break;
    case "back": shape = <><path d="M19 12H5M11 18l-6-6 6-6"/></>; break;
    case "eye": shape = <><path d="M2.5 12s3.3-6 9.5-6 9.5 6 9.5 6-3.3 6-9.5 6-9.5-6-9.5-6Z"/><circle cx="12" cy="12" r="2.5"/></>; break;
    case "eyeOff": shape = <><path d="m3 3 18 18M10.6 10.6a2 2 0 0 0 2.8 2.8"/><path d="M9.9 5.2A10 10 0 0 1 12 5c6.2 0 9.5 7 9.5 7a14.6 14.6 0 0 1-3.2 3.9M6.2 6.2C3.8 7.7 2.5 12 2.5 12s3.3 7 9.5 7c1.3 0 2.4-.3 3.4-.8"/></>; break;
    case "lock": shape = <><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3"/></>; break;
    case "logout": shape = <><path d="M10 17l5-5-5-5M15 12H3"/><path d="M12 3h6a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-6"/></>; break;
    case "money": shape = <><circle cx="12" cy="12" r="9"/><path d="M15.5 8.5c-.8-1-2-1.5-3.5-1.5-1.7 0-3 .8-3 2s1.4 1.8 3.2 2.3c1.8.4 3.3 1.1 3.3 2.7 0 1.5-1.5 2.5-3.5 2.5-1.6 0-3-.6-3.8-1.8M12 5v14"/></>; break;
    case "orders": shape = <><path d="M6 3.5h12v17l-3-1.8-3 1.8-3-1.8-3 1.8v-17Z"/><path d="M9 8h6M9 12h6M9 16h3"/></>; break;
    case "reports": shape = <><path d="M4 20V11M10 20V5M16 20v-7M22 20H2"/><path d="m4 8 6-4 6 5 5-5"/></>; break;
    case "products": shape = <><path d="M4 8h16v12H4zM3 8l2-5h14l2 5M9 8v4h6V8"/></>; break;
    case "categories": shape = <><rect x="3" y="3" width="8" height="8" rx="2"/><rect x="13" y="3" width="8" height="8" rx="2"/><rect x="3" y="13" width="8" height="8" rx="2"/><rect x="13" y="13" width="8" height="8" rx="2"/></>; break;
    case "tables": shape = <><path d="M3 8h18M5 8v12M19 8v12M3 13h18M8 8V5h8v3"/></>; break;
    case "users": shape = <><circle cx="9" cy="8" r="4"/><path d="M2 21a7 7 0 0 1 14 0M16 4.5a4 4 0 0 1 0 7.5M18 15a6 6 0 0 1 4 6"/></>; break;
    case "settings": shape = <><circle cx="12" cy="12" r="3"/><path d="m19.4 15 .1.1a1.8 1.8 0 0 1-2.5 2.5l-.1-.1a1.8 1.8 0 0 0-3 .9v.2a1.8 1.8 0 0 1-3.6 0v-.2a1.8 1.8 0 0 0-3-.9l-.1.1a1.8 1.8 0 0 1-2.5-2.5l.1-.1a1.8 1.8 0 0 0-.9-3h-.2a1.8 1.8 0 0 1 0-3.6h.2a1.8 1.8 0 0 0 .9-3l-.1-.1a1.8 1.8 0 0 1 2.5-2.5l.1.1a1.8 1.8 0 0 0 3-.9v-.2a1.8 1.8 0 0 1 3.6 0v.2a1.8 1.8 0 0 0 3 .9l.1-.1a1.8 1.8 0 0 1 2.5 2.5l-.1.1a1.8 1.8 0 0 0 .9 3h.2a1.8 1.8 0 0 1 0 3.6h-.2a1.8 1.8 0 0 0-.9 3Z"/></>; break;
    case "backup": shape = <><path d="M12 16V3M7 8l5-5 5 5M4 14v6h16v-6"/></>; break;
    case "arrow": shape = <><path d="M5 12h14M13 6l6 6-6 6"/></>; break;
    case "refresh": shape = <><path d="M20 7v5h-5M4 17v-5h5"/><path d="M5.6 9A7 7 0 0 1 18 6l2 2M4 16l2 2a7 7 0 0 0 12.4-3"/></>; break;
    case "plus": shape = <path d="M12 5v14M5 12h14"/>; break;
    case "edit": shape = <><path d="m15 5 4 4M4 20l4-.8L19 8a2.8 2.8 0 0 0-4-4L4 15v5Z"/></>; break;
    case "trash": shape = <><path d="M4 7h16M10 11v6M14 11v6M5.5 7l1 13h11l1-13M9 7V4h6v3"/></>; break;
    case "close": shape = <path d="m6 6 12 12M18 6 6 18"/>; break;
    case "check": shape = <path d="m5 12 4.3 4.3L19.5 6"/>; break;
    case "upload": shape = <><path d="M12 16V3M7 8l5-5 5 5M4 14v6h16v-6"/></>; break;
    case "download": shape = <><path d="M12 3v13M7 11l5 5 5-5M4 20h16"/></>; break;
    case "search": shape = <><circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 4.2 4.2"/></>; break;
    case "clock": shape = <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/></>; break;
    case "calendar": shape = <><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/></>; break;
    case "receipt": shape = <><path d="M6 3.5h12v17l-3-1.8-3 1.8-3-1.8-3 1.8v-17Z"/><path d="M9 8h6M9 12h6"/></>; break;
    case "save": shape = <><path d="M5 3h12l4 4v14H3V3h2ZM7 3v6h10V3M7 21v-8h10v8"/></>; break;
    default: shape = <circle cx="12" cy="12" r="8"/>;
  }
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">{shape}</svg>;
}

function escapeHtml(value: string) {
  return value.replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character] ?? character);
}

function orderTypeName(value: string) {
  if (value === "delivery") return "توصيل";
  if (value === "takeaway") return "سفري";
  return "صالة";
}

function printInvoice(order: RestaurantOrder, settings: RestaurantSettings) {
  const popup = window.open("", "_blank", "width=420,height=740");
  if (!popup) throw new Error("اسمح بالنوافذ المنبثقة لطباعة الفاتورة");
  const image = settings.logo ? `<img src="${escapeHtml(settings.logo)}" alt="${escapeHtml(settings.restaurantName)}" class="logo">` : "";
  const rows = order.items.map((item) => `<div class="row"><span>${escapeHtml(item.name)} × ${formatNumber(item.quantity)}</span><b>${formatMoney(item.lineTotal)}</b></div>`).join("");
  const totalRows = `<div class="row"><span>المجموع الفرعي</span><span>${formatMoney(order.subtotal)}</span></div>${order.discount ? `<div class="row"><span>الخصم</span><span>− ${formatMoney(order.discount)}</span></div>` : ""}<div class="row"><span>الضريبة</span><span>${formatMoney(order.tax)}</span></div>${order.service ? `<div class="row"><span>الخدمة</span><span>${formatMoney(order.service)}</span></div>` : ""}${order.deliveryFee ? `<div class="row"><span>التوصيل</span><span>${formatMoney(order.deliveryFee)}</span></div>` : ""}<div class="row total"><b>الصافي</b><b>${formatMoney(order.total)}</b></div>`;
  const cancelledNote = order.status === "cancelled" ? `<div class="muted">فاتورة ملغاة · ${escapeHtml(order.cancelReason)}</div>` : "";
  popup.document.write(`<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>${escapeHtml(settings.restaurantName)} ${escapeHtml(order.receiptNumber)}</title><style>body{font-family:Arial,sans-serif;color:#222;margin:18px;font-size:12px}.center{text-align:center}.logo{max-width:75px;max-height:65px;object-fit:contain}.title{font-size:19px;font-weight:bold;margin:7px}.muted{color:#777;font-size:10px;margin:4px}.rule{border-top:1px dashed #999;margin:13px 0}.row{display:flex;justify-content:space-between;gap:12px;margin:9px 0}.row b{white-space:nowrap}.total{font-size:15px;font-weight:bold;border-top:1px solid #aaa;padding-top:10px}.items{margin-top:13px}.footer{margin-top:18px;text-align:center;color:#555}@media print{@page{size:80mm auto;margin:5mm}}</style></head><body><div class="center">${image}<div class="title">${escapeHtml(settings.restaurantName)}</div>${settings.address ? `<div class="muted">${escapeHtml(settings.address)}</div>` : ""}${settings.phone ? `<div class="muted">${escapeHtml(settings.phone)}</div>` : ""}<div class="muted">${escapeHtml(order.receiptNumber)} · ${formatDateTime(order.createdAt)}</div><div class="muted">الكاشير: ${escapeHtml(order.cashier)}</div></div>${cancelledNote}<div class="rule"></div><div class="items">${rows}</div><div class="rule"></div>${totalRows}<div class="row"><span>طريقة التحصيل</span><span>${order.paymentMethod === "cash" ? "نقدي" : order.paymentMethod === "card" ? "بطاقة" : "محفظة"}</span></div>${order.paymentMethod === "cash" ? `<div class="row"><span>المبلغ المستلم</span><span>${formatMoney(order.cashReceived)}</span></div><div class="row"><span>الباقي</span><span>${formatMoney(order.changeDue)}</span></div>` : ""}${settings.taxNumber ? `<div class="muted">الرقم الضريبي: ${escapeHtml(settings.taxNumber)}</div>` : ""}${order.notes ? `<div class="muted">تعليق: ${escapeHtml(order.notes)}</div>` : ""}<div class="footer">${escapeHtml(settings.receiptMessage)}</div><script>window.onload=()=>{window.print();window.onafterprint=()=>window.close()}</script></body></html>`);
  popup.document.close();
}

const emptyProduct: ProductDraft = { id: "", name: "", description: "", category: "", price: "", image: "", badge: "", active: true };
const emptyUser: UserDraft = { id: "", name: "", username: "", role: "cashier", password: "", active: true };

export default function AdminPage() {
  const [snapshot, setSnapshot] = useState<DataSnapshot | null>(null);
  const [initialLoading, setInitialLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [manager, setManager] = useState<RestaurantUser | null>(null);
  const [username, setUsername] = useState("admin");
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const [loginLoading, setLoginLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [forcePasswordChange, setForcePasswordChange] = useState(false);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [activeTab, setActiveTab] = useState<TabId>("overview");
  const [toast, setToast] = useState("");
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [productDraft, setProductDraft] = useState<ProductDraft>(emptyProduct);
  const [productModal, setProductModal] = useState(false);
  const [categoryName, setCategoryName] = useState("");
  const [editingCategory, setEditingCategory] = useState<string | null>(null);
  const [tableName, setTableName] = useState("");
  const [editingTable, setEditingTable] = useState<string | null>(null);
  const [userDraft, setUserDraft] = useState<UserDraft>(emptyUser);
  const [userModal, setUserModal] = useState(false);
  const [settingsDraft, setSettingsDraft] = useState<RestaurantSettings | null>(null);
  const [settingsDirty, setSettingsDirty] = useState(false);
  const [logoUrl, setLogoUrl] = useState("");
  const [invoiceQuery, setInvoiceQuery] = useState("");
  const [invoiceStatus, setInvoiceStatus] = useState("all");
  const [invoiceFrom, setInvoiceFrom] = useState(toIsoDate(new Date()));
  const [invoiceTo, setInvoiceTo] = useState(toIsoDate(new Date()));
  const [cancelTarget, setCancelTarget] = useState<RestaurantOrder | null>(null);
  const [cancelReason, setCancelReason] = useState("");
  const [reportPeriod, setReportPeriod] = useState<"day" | "week" | "month" | "custom">("day");
  const [reportFrom, setReportFrom] = useState(toIsoDate(new Date()));
  const [reportTo, setReportTo] = useState(toIsoDate(new Date()));
  const [currentPassword, setCurrentPassword] = useState("");
  const [accountNewPassword, setAccountNewPassword] = useState("");
  const [accountConfirmPassword, setAccountConfirmPassword] = useState("");

  const reload = useCallback(async () => {
    try {
      const data = await readSnapshot();
      setSnapshot(data);
      setLoadError("");
    } catch (error) {
      setLoadError(error instanceof Error ? error.message : "تعذر فتح قاعدة البيانات المحلية");
    } finally {
      setInitialLoading(false);
    }
  }, []);

  const showToast = useCallback((message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 3200);
  }, []);

  useEffect(() => {
    void reload();
    const unsubscribe = subscribeToDataChanges(() => void reload());
    return unsubscribe;
  }, [reload]);

  useEffect(() => {
    setRestaurantFavicon(snapshot?.settings.logo ?? "", snapshot?.settings.restaurantName ?? "مذاق البلد");
    if (snapshot && !settingsDirty) setSettingsDraft(snapshot.settings);
  }, [snapshot, settingsDirty]);

  const products = useMemo(() => snapshot?.products ?? [], [snapshot?.products]);
  const categories = useMemo(() => snapshot?.categories ?? [], [snapshot?.categories]);
  const users = useMemo(() => snapshot?.users ?? [], [snapshot?.users]);
  const orders = useMemo(() => snapshot?.orders ?? [], [snapshot?.orders]);
  const settings = snapshot?.settings;
  const currentTabName = tabs.find((tab) => tab.id === activeTab)?.label ?? "الرئيسية";
  const selectedCategoryFilter = categories.some((category) => category.name === categoryFilter) ? categoryFilter : "all";

  const filteredProducts = useMemo(() => {
    const normalized = search.trim().toLocaleLowerCase();
    return products.filter((product) => (selectedCategoryFilter === "all" || product.category === selectedCategoryFilter) && (!normalized || `${product.name} ${product.description} ${product.category}`.toLocaleLowerCase().includes(normalized)));
  }, [products, search, selectedCategoryFilter]);

  const filteredInvoices = useMemo(() => {
    const normalized = invoiceQuery.trim().toLocaleLowerCase();
    const start = invoiceFrom ? new Date(`${invoiceFrom}T00:00:00`) : null;
    const end = invoiceTo ? new Date(`${invoiceTo}T23:59:59.999`) : null;
    return orders.filter((order) => {
      const created = new Date(order.createdAt);
      const matchesQuery = !normalized || `${order.receiptNumber} ${order.customerName ?? ""} ${order.cashier} ${order.tableLabel ?? ""} ${order.items.map((item) => item.name).join(" ")}`.toLocaleLowerCase().includes(normalized);
      const matchesStatus = invoiceStatus === "all" || order.status === invoiceStatus;
      const matchesDate = (!start || created >= start) && (!end || created <= end);
      return matchesQuery && matchesStatus && matchesDate;
    });
  }, [orders, invoiceQuery, invoiceStatus, invoiceFrom, invoiceTo]);

  const reportOrders = useMemo(() => {
    let start: Date;
    let end: Date;
    if (reportPeriod === "custom") {
      start = reportFrom ? new Date(`${reportFrom}T00:00:00`) : new Date(0);
      end = reportTo ? new Date(`${reportTo}T23:59:59.999`) : new Date();
    } else {
      const now = new Date();
      if (reportPeriod === "day") start = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      else if (reportPeriod === "week") {
        start = new Date(now);
        start.setDate(start.getDate() - ((start.getDay() + 6) % 7));
        start.setHours(0, 0, 0, 0);
      } else start = new Date(now.getFullYear(), now.getMonth(), 1);
      end = new Date();
    }
    return orders.filter((order) => order.status === "paid" && new Date(order.createdAt) >= start && new Date(order.createdAt) <= end);
  }, [orders, reportPeriod, reportFrom, reportTo]);

  const reportRevenue = reportOrders.reduce((sum, order) => sum + order.total, 0);
  const bestSellers = useMemo(() => {
    const tally = new Map<string, { name: string; quantity: number; revenue: number }>();
    for (const order of reportOrders) for (const item of order.items) {
      const previous = tally.get(item.productId) ?? { name: item.name, quantity: 0, revenue: 0 };
      previous.quantity += item.quantity;
      previous.revenue += item.lineTotal;
      tally.set(item.productId, previous);
    }
    return [...tally.values()].sort((a, b) => b.quantity - a.quantity).slice(0, 8);
  }, [reportOrders]);
  const paymentTotals = useMemo(() => {
    const result = new Map<string, { count: number; amount: number }>();
    for (const order of reportOrders) {
      const previous = result.get(order.paymentMethod) ?? { count: 0, amount: 0 };
      previous.count += 1;
      previous.amount += order.total;
      result.set(order.paymentMethod, previous);
    }
    return [...result.entries()];
  }, [reportOrders]);
  const cashierTotals = useMemo(() => {
    const result = new Map<string, { name: string; count: number; amount: number }>();
    for (const order of reportOrders) {
      const previous = result.get(order.cashierId) ?? { name: order.cashier, count: 0, amount: 0 };
      previous.count += 1;
      previous.amount += order.total;
      result.set(order.cashierId, previous);
    }
    return [...result.values()].sort((a, b) => b.amount - a.amount);
  }, [reportOrders]);

  async function submitLogin(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!username.trim() || !password || loginLoading) return;
    setLoginLoading(true);
    setLoginError("");
    try {
      const user = await verifyUser(username, password, "manager");
      if (!user) throw new Error("اسم المستخدم أو كلمة المرور غير صحيحة");
      setManager(user);
      setForcePasswordChange(user.mustChangePassword);
      setPassword("");
    } catch (error) {
      setLoginError(error instanceof Error ? error.message : "تعذر تسجيل الدخول");
    } finally {
      setLoginLoading(false);
    }
  }

  async function submitForcedPassword(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!manager) return;
    if (newPassword.length < 6) { setLoginError("كلمة المرور يجب ألا تقل عن 6 أحرف"); return; }
    if (newPassword !== confirmPassword) { setLoginError("كلمتا المرور غير متطابقتين"); return; }
    if (await verifyUser(manager.username, newPassword, "manager")) { setLoginError("اختر كلمة مرور مختلفة"); return; }
    setLoginLoading(true);
    setLoginError("");
    try {
      await changeOwnPassword(manager.id, newPassword);
      const updated = (await readSnapshot()).users.find((user) => user.id === manager.id) ?? manager;
      setManager(updated);
      setForcePasswordChange(false);
      setNewPassword("");
      setConfirmPassword("");
      await reload();
      showToast("تم تحديث كلمة المرور");
    } catch (error) {
      setLoginError(error instanceof Error ? error.message : "تعذر تحديث كلمة المرور");
    } finally {
      setLoginLoading(false);
    }
  }

  async function saveManagerPassword(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!manager) return;
    if (accountNewPassword.length < 6) { showToast("كلمة المرور يجب ألا تقل عن 6 أحرف"); return; }
    if (accountNewPassword !== accountConfirmPassword) { showToast("كلمتا المرور غير متطابقتين"); return; }
    try {
      const verified = await verifyUser(manager.username, currentPassword, "manager");
      if (!verified) { showToast("كلمة المرور الحالية غير صحيحة"); return; }
      await changeOwnPassword(manager.id, accountNewPassword);
      const updated = (await readSnapshot()).users.find((user) => user.id === manager.id) ?? manager;
      setManager(updated);
      setCurrentPassword(""); setAccountNewPassword(""); setAccountConfirmPassword("");
      showToast("تم تحديث كلمة المرور");
    } catch (error) {
      showToast(error instanceof Error ? error.message : "تعذر تحديث كلمة المرور");
    }
  }

  async function saveProductForm(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!productDraft.name.trim() || !productDraft.category || Number(productDraft.price) < 0) { showToast("أكمل بيانات الصنف"); return; }
    const product: MenuProduct = {
      id: productDraft.id || `custom-${crypto.randomUUID()}`,
      name: productDraft.name.trim(),
      description: productDraft.description.trim(),
      category: productDraft.category,
      price: Math.max(0, Math.round(Number(productDraft.price) || 0)),
      image: productDraft.image.trim(),
      ...(productDraft.badge ? { badge: productDraft.badge, popular: productDraft.badge === "الأكثر طلباً" } : {}),
      active: productDraft.active,
    };
    try {
      await saveProduct(product);
      setProductModal(false);
      setProductDraft(emptyProduct);
      showToast("تم حفظ الصنف");
    } catch (error) { showToast(error instanceof Error ? error.message : "تعذر حفظ الصنف"); }
  }

  async function uploadProductImage(file?: File) {
    if (!file) return;
    try {
      const image = await compressImageFile(file);
      setProductDraft((current) => ({ ...current, image }));
      showToast("تم حفظ الصورة للمعاينة");
    } catch (error) { showToast(error instanceof Error ? error.message : "تعذر تجهيز الصورة"); }
  }

  async function saveCategoryForm(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const clean = categoryName.trim();
    if (!clean) return;
    try {
      if (editingCategory) await renameCategory(editingCategory, clean);
      else {
        if (categories.some((item) => item.name.toLocaleLowerCase() === clean.toLocaleLowerCase())) throw new Error("اسم القسم مستخدم بالفعل");
        await saveCategory({ id: clean, name: clean, sortOrder: categories.length });
      }
      setCategoryName(""); setEditingCategory(null); showToast("تم حفظ القسم");
    } catch (error) { showToast(error instanceof Error ? error.message : "تعذر حفظ القسم"); }
  }

  async function moveCategory(index: number, amount: number) {
    const next = [...categories];
    const destination = index + amount;
    if (destination < 0 || destination >= next.length) return;
    [next[index], next[destination]] = [next[destination], next[index]];
    try { await reorderCategories(next); }
    catch (error) { showToast(error instanceof Error ? error.message : "تعذر ترتيب الأقسام"); }
  }

  async function addOrEditTable(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const name = tableName.trim();
    if (!name) return;
    if (snapshot?.tables.some((table) => table.name.toLocaleLowerCase() === name.toLocaleLowerCase() && table.id !== editingTable)) { showToast("اسم الطاولة موجود"); return; }
    const table: RestaurantTable = { id: editingTable ?? `table-${crypto.randomUUID()}`, name, active: true };
    try {
      await saveTable(table);
      setTableName(""); setEditingTable(null); showToast("تم حفظ الطاولة");
    } catch (error) { showToast(error instanceof Error ? error.message : "تعذر حفظ الطاولة"); }
  }

  async function saveUserForm(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const editing = users.find((user) => user.id === userDraft.id);
    if (!userDraft.name.trim() || !userDraft.username.trim()) { showToast("أكمل اسم المستخدم واسم العرض"); return; }
    if (!editing && userDraft.password.length < 6) { showToast("كلمة المرور يجب ألا تقل عن 6 أحرف"); return; }
    if (userDraft.password && userDraft.password.length < 6) { showToast("كلمة المرور يجب ألا تقل عن 6 أحرف"); return; }
    try {
      const base: RestaurantUser = editing ?? { id: `user-${crypto.randomUUID()}`, name: "", username: "", role: userDraft.role, salt: "", passwordHash: "", mustChangePassword: false, active: userDraft.active };
      const user: RestaurantUser = { ...base, name: userDraft.name.trim(), username: userDraft.username.trim(), role: userDraft.role, active: userDraft.active };
      await saveUser(user, userDraft.password || undefined);
      if (manager?.id === user.id) {
        const updatedSnapshot = await readSnapshot();
        setSnapshot(updatedSnapshot);
        const updatedManager = updatedSnapshot.users.find((entry) => entry.id === manager.id);
        if (!updatedManager || !updatedManager.active || updatedManager.role !== "manager") setManager(null);
        else setManager(updatedManager);
      }
      setUserModal(false); setUserDraft(emptyUser); showToast("تم حفظ المستخدم");
    } catch (error) { showToast(error instanceof Error ? error.message : "تعذر حفظ المستخدم"); }
  }

  async function toggleUserActivation(user: RestaurantUser) {
    await saveUser({ ...user, active: !user.active });
    if (manager?.id === user.id && user.active) setManager(null);
  }

  async function removeUserAccount(user: RestaurantUser) {
    if (!window.confirm(`حذف المستخدم ${user.name}؟`)) return;
    await deleteUser(user.id);
    if (manager?.id === user.id) setManager(null);
    showToast("تم حذف المستخدم");
  }

  async function uploadRestaurantLogo(file?: File) {
    if (!file || !settingsDraft) return;
    try {
      if (!/^image\/(png|jpeg|svg\+xml|webp)$/.test(file.type)) throw new Error("صيغة الشعار يجب أن تكون PNG أو SVG أو JPG");
      const logo = await compressImageFile(file, 720);
      setSettingsDraft({ ...settingsDraft, logo }); setSettingsDirty(true);
    } catch (error) { showToast(error instanceof Error ? error.message : "تعذر رفع الشعار"); }
  }

  async function saveSettingsForm(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!settingsDraft) return;
    try {
      await saveSettings({ ...settingsDraft, taxRate: Math.max(0, Number(settingsDraft.taxRate) || 0), serviceRate: Math.max(0, Number(settingsDraft.serviceRate) || 0), deliveryFee: Math.max(0, Math.round(Number(settingsDraft.deliveryFee) || 0)) });
      setSettingsDirty(false); showToast("تم حفظ الإعدادات");
    } catch (error) { showToast(error instanceof Error ? error.message : "تعذر حفظ الإعدادات"); }
  }

  async function submitCancelOrder(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!manager || !cancelTarget || !cancelReason.trim()) { showToast("اكتب سبب الإلغاء"); return; }
    if (!window.confirm(`إلغاء الفاتورة ${cancelTarget.receiptNumber}؟`)) return;
    try {
      await cancelOrder(cancelTarget.id, cancelReason, manager);
      setCancelTarget(null); setCancelReason(""); showToast("تم إلغاء الفاتورة وتسجيل السبب");
    } catch (error) { showToast(error instanceof Error ? error.message : "تعذر إلغاء الفاتورة"); }
  }

  async function downloadBackup() {
    try {
      const backup = await exportDataBackup();
      const blob = new Blob([JSON.stringify(backup, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a"); anchor.href = url; anchor.download = `mazaq-backup-${toIsoDate(new Date())}.json`;
      anchor.click(); URL.revokeObjectURL(url); showToast("تم تنزيل النسخة الاحتياطية");
    } catch (error) { showToast(error instanceof Error ? error.message : "تعذر إنشاء النسخة الاحتياطية"); }
  }

  async function uploadBackup(file?: File) {
    if (!file) return;
    if (!window.confirm("استيراد النسخة سيستبدل جميع البيانات الحالية. متابعة؟")) return;
    try {
      const value = JSON.parse(await file.text()) as { users?: RestaurantUser[] };
      if (!Array.isArray(value.users) || !value.users.some((user) => user.role === "manager" && user.active)) throw new Error("يجب أن تحتوي النسخة على مدير نشط");
      await importDataBackup(value);
      setManager(null); setActiveTab("overview"); showToast("تم استيراد النسخة الاحتياطية");
    } catch (error) { showToast(error instanceof Error ? error.message : "ملف النسخة الاحتياطية غير صالح"); }
  }

  async function resetDemoData() {
    if (!window.confirm("سيتم حذف الفواتير والبيانات التجريبية وإعادة الإعدادات الافتراضية. متابعة؟")) return;
    try {
      await resetAllData();
      setManager(null); setSnapshot(null); setActiveTab("overview");
      showToast("تم تصفير البيانات");
    } catch (error) { showToast(error instanceof Error ? error.message : "تعذر تصفير البيانات"); }
  }

  function exportReportCsv() {
    const rows = [
      ["رقم الفاتورة", "التاريخ", "الكاشير", "العميل", "طريقة الدفع", "المجموع", "الخصم", "الضريبة", "الخدمة", "التوصيل", "الصافي", "الحالة"],
      ...reportOrders.map((order) => [order.receiptNumber, formatDateTime(order.createdAt), order.cashier, order.customerName ?? "", order.paymentMethod, order.subtotal, order.discount, order.tax, order.service, order.deliveryFee, order.total, order.status]),
    ];
    const csv = `\uFEFF${rows.map((row) => row.map((value) => `"${String(value).replaceAll('"', '""')}"`).join(",")).join("\r\n")}`;
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    const anchor = document.createElement("a"); anchor.href = url; anchor.download = `mazaq-report-${toIsoDate(new Date())}.csv`;
    anchor.click(); URL.revokeObjectURL(url);
  }

  if (initialLoading) return <div className="admin-page"><div className="admin-loading-state">جارٍ تحميل البيانات...</div></div>;
  if (loadError && !snapshot) return <div className="admin-page"><div className="admin-error-state"><strong>{loadError}</strong><button type="button" onClick={() => void reload()}>إعادة المحاولة</button></div></div>;

  if (!manager) return <main className="admin-page admin-login-wrap"><section className="admin-login-card" aria-label="دخول الإدارة">
    <div className="admin-login-art"><DishImage src={products.find((product) => product.category === "مشويات")?.image ?? ""} name={settings?.restaurantName ?? "مذاق البلد"} className="admin-login-photo-image" /><div className="admin-art-brand"><RestaurantLogo logo={settings?.logo} name={settings?.restaurantName ?? "مذاق البلد"} /><span><strong>{settings?.restaurantName ?? "مذاق البلد"}</strong><small>الإدارة</small></span></div><div className="admin-art-copy"><h2>دخول الإدارة</h2></div><div className="admin-art-foot"><AdminIcon name="lock" size={14} /> مدير النظام</div></div>
    <div className="admin-login-form-wrap"><Link className="admin-back-link" href="/"><AdminIcon name="back" size={16} /> شاشة الكاشير</Link><h1>تسجيل الدخول</h1><form onSubmit={(event) => void submitLogin(event)}><label className="admin-login-label" htmlFor="admin-username">اسم المستخدم</label><div className="admin-password-field"><AdminIcon name="users" size={17} /><input id="admin-username" autoComplete="username" value={username} onChange={(event) => setUsername(event.target.value)} required /></div><label className="admin-login-label login-password-label" htmlFor="admin-password">كلمة المرور</label><div className="admin-password-field"><AdminIcon name="lock" size={18} /><input id="admin-password" type={showPassword ? "text" : "password"} autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} required /><button className="password-toggle" type="button" onClick={() => setShowPassword((value) => !value)} aria-label={showPassword ? "إخفاء كلمة المرور" : "إظهار كلمة المرور"}><AdminIcon name={showPassword ? "eyeOff" : "eye"} size={17} /></button></div>{loginError && <div className="admin-login-error" role="alert">{loginError}</div>}<button className="admin-login-submit" type="submit" disabled={loginLoading || !password}>{loginLoading ? "جارٍ التحقق..." : "دخول"}</button></form></div>
  </section></main>;

  return <main className="admin-page admin-dashboard">
    <header className="admin-topbar"><Link href="/" className="admin-topbar-brand"><RestaurantLogo logo={settings?.logo} name={settings?.restaurantName ?? "مذاق البلد"} /><span><strong>{settings?.restaurantName ?? "مذاق البلد"}</strong><small>لوحة الإدارة</small></span></Link><div className="admin-topbar-tools"><div className="admin-user-chip"><span>{manager.name.slice(0, 1)}</span><span><strong>{manager.name}</strong><small>مدير</small></span></div><button className="admin-logout" type="button" onClick={() => { setManager(null); setActiveTab("overview"); }}><AdminIcon name="logout" size={15} /> تسجيل الخروج</button></div></header>

    <div className="admin-body">
      <div className="admin-welcome-row"><div><h1>{currentTabName}</h1></div><div className="admin-today-chip"><AdminIcon name="calendar" size={15} /> {formatDate(new Date())}</div></div>
      <nav className="admin-tabs" aria-label="أقسام الإدارة">{tabs.map((tab) => <button className={`admin-tab ${activeTab === tab.id ? "selected" : ""}`} type="button" key={tab.id} onClick={() => setActiveTab(tab.id)}><AdminIcon name={tab.icon} size={17} />{tab.label}</button>)}</nav>

      {activeTab === "overview" && <>
        <section className="admin-stats-grid" aria-label="إحصائيات اليوم"><article className="admin-stat-card"><div><span>مبيعات اليوم</span><strong>{formatMoney(orders.filter((order) => order.status === "paid" && new Date(order.createdAt).toDateString() === new Date().toDateString()).reduce((sum, order) => sum + order.total, 0))}</strong></div><span className="admin-stat-icon"><AdminIcon name="money" size={19} /></span></article><article className="admin-stat-card"><div><span>طلبات اليوم</span><strong>{formatNumber(orders.filter((order) => order.status === "paid" && new Date(order.createdAt).toDateString() === new Date().toDateString()).length)}</strong></div><span className="admin-stat-icon"><AdminIcon name="orders" size={19} /></span></article><article className="admin-stat-card"><div><span>متوسط الفاتورة</span><strong>{formatMoney((() => { const today = orders.filter((order) => order.status === "paid" && new Date(order.createdAt).toDateString() === new Date().toDateString()); return today.length ? Math.round(today.reduce((sum, order) => sum + order.total, 0) / today.length) : 0; })())}</strong></div><span className="admin-stat-icon"><AdminIcon name="reports" size={19} /></span></article><article className="admin-stat-card"><div><span>أصناف المنيو</span><strong>{formatNumber(products.filter((product) => product.active !== false).length)}</strong></div><span className="admin-stat-icon"><AdminIcon name="products" size={19} /></span></article></section>
        <div className="admin-content-grid"><section className="admin-panel"><div className="admin-panel-heading"><div><h2>آخر الفواتير</h2></div><button className="admin-panel-link" type="button" onClick={() => setActiveTab("invoices")}><AdminIcon name="arrow" size={14} /> كل الفواتير</button></div>{orders.length === 0 ? <div className="admin-empty-recent">لا توجد فواتير</div> : <div className="admin-recent-list">{orders.slice(0, 7).map((order) => <div className="admin-recent-row" key={order.id}><div className="admin-recent-receipt"><span className="admin-receipt-icon"><AdminIcon name="orders" size={15} /></span><span><strong>{order.receiptNumber}</strong><small>{order.cashier} · {formatDateTime(order.createdAt)}</small></span></div><span className={`order-status ${order.status}`}>{order.status === "cancelled" ? "ملغاة" : "مدفوعة"}</span><strong className="admin-recent-total">{formatMoney(order.total)}</strong></div>)}</div>}</section><section className="admin-panel"><div className="admin-panel-heading"><div><h2>الأصناف</h2></div><button className="admin-panel-link" type="button" onClick={() => setActiveTab("products")}><AdminIcon name="arrow" size={14} /> إدارة الأصناف</button></div><div className="admin-menu-list">{products.filter((product) => product.active !== false).slice(0, 5).map((product) => <div className="admin-menu-row" key={product.id}><span className="admin-menu-thumb"><DishImage src={product.image} name={product.name} /></span><span className="admin-menu-text"><strong>{product.name}</strong><small>{product.category}</small></span><strong className="admin-menu-price">{formatMoney(product.price)}</strong></div>)}</div><p className="admin-photo-credit">{formatNumber(products.length)} صنف · {formatNumber(categories.length)} قسم</p></section></div>
      </>}

      {activeTab === "products" && <section className="admin-panel management-panel"><div className="admin-panel-heading"><div><h2>الأصناف</h2></div><button className="primary-button" type="button" onClick={() => { setProductDraft({ ...emptyProduct, category: categories[0]?.name ?? "" }); setProductModal(true); }}><AdminIcon name="plus" size={16} /> إضافة صنف</button></div><div className="management-toolbar"><label className="search-field management-search"><AdminIcon name="search" size={17} /><input placeholder="بحث في الأصناف" value={search} onChange={(event) => setSearch(event.target.value)} /></label><select className="management-select" value={selectedCategoryFilter} onChange={(event) => setCategoryFilter(event.target.value)}><option value="all">كل الأقسام</option>{categories.map((item) => <option key={item.id} value={item.name}>{item.name}</option>)}</select></div><div className="admin-product-grid">{filteredProducts.map((product) => <article className={`admin-product-card ${product.active === false ? "inactive" : ""}`} key={product.id}><div className="admin-product-photo"><DishImage src={product.image} name={product.name} />{product.badge && <span className="product-badge">{product.badge}</span>}<span className={`product-visibility ${product.active === false ? "hidden" : ""}`}>{product.active === false ? "مخفي" : "ظاهر"}</span></div><div className="admin-product-info"><span className="product-category-label">{product.category}</span><strong>{product.name}</strong><small>{product.description || "—"}</small><b>{formatMoney(product.price)}</b><div className="admin-row-actions"><button type="button" className="secondary-button" onClick={() => { setProductDraft({ id: product.id, name: product.name, description: product.description, category: product.category, price: String(product.price), image: product.image, badge: product.badge ?? "", active: product.active !== false }); setProductModal(true); }}><AdminIcon name="edit" size={14} /> تعديل</button><button type="button" className="icon-action-button" aria-label={product.active === false ? "إظهار الصنف" : "إخفاء الصنف"} title={product.active === false ? "إظهار" : "إخفاء"} onClick={() => void saveProduct({ ...product, active: product.active === false }).catch((error: unknown) => showToast(error instanceof Error ? error.message : "تعذر تحديث الصنف"))}><AdminIcon name={product.active === false ? "eye" : "eyeOff"} size={15} /></button><button type="button" className="icon-action-button danger" aria-label="حذف الصنف" title="حذف" onClick={() => { if (window.confirm(`حذف صنف ${product.name}؟`)) void deleteProduct(product.id).then(() => showToast("تم حذف الصنف")).catch((error: unknown) => showToast(error instanceof Error ? error.message : "تعذر حذف الصنف")); }}><AdminIcon name="trash" size={15} /></button></div></div></article>)}</div>{filteredProducts.length === 0 && <div className="management-empty">لا توجد أصناف مطابقة</div>}</section>}

      {activeTab === "categories" && <div className="admin-two-column"><section className="admin-panel"><div className="admin-panel-heading"><div><h2>{editingCategory ? "تعديل القسم" : "إضافة قسم"}</h2></div></div><form className="admin-form" onSubmit={(event) => void saveCategoryForm(event)}><label>اسم القسم<input value={categoryName} onChange={(event) => setCategoryName(event.target.value)} required /></label><div className="admin-form-actions"><button className="primary-button" type="submit"><AdminIcon name="save" size={16} /> حفظ</button>{editingCategory && <button className="secondary-button" type="button" onClick={() => { setEditingCategory(null); setCategoryName(""); }}>إلغاء</button>}</div></form></section><section className="admin-panel"><div className="admin-panel-heading"><div><h2>ترتيب الأقسام</h2></div></div><div className="category-manager-list">{categories.map((category, index) => <div className="category-manager-row" key={category.id}><span className="category-order-number">{formatNumber(index + 1)}</span><strong>{category.name}</strong><span className="category-item-count">{formatNumber(products.filter((product) => product.category === category.name).length)} صنف</span><button className="icon-action-button" type="button" disabled={index === 0} aria-label="تحريك لأعلى" onClick={() => void moveCategory(index, -1)}>↑</button><button className="icon-action-button" type="button" disabled={index === categories.length - 1} aria-label="تحريك لأسفل" onClick={() => void moveCategory(index, 1)}>↓</button><button className="icon-action-button" type="button" aria-label="تعديل القسم" onClick={() => { setEditingCategory(category.id); setCategoryName(category.name); }}><AdminIcon name="edit" size={14} /></button><button className="icon-action-button danger" type="button" aria-label="حذف القسم" onClick={() => { if (window.confirm(`حذف قسم ${category.name}؟`)) void deleteCategory(category.id).then(() => showToast("تم حذف القسم")).catch((error: unknown) => showToast(error instanceof Error ? error.message : "تعذر حذف القسم")); }}><AdminIcon name="trash" size={14} /></button></div>)}</div></section></div>}

      {activeTab === "tables" && <div className="admin-two-column"><section className="admin-panel"><div className="admin-panel-heading"><div><h2>{editingTable ? "تعديل الطاولة" : "إضافة طاولة"}</h2></div></div><form className="admin-form" onSubmit={(event) => void addOrEditTable(event)}><label>اسم الطاولة<input value={tableName} onChange={(event) => setTableName(event.target.value)} placeholder="مثال: طاولة 1" required /></label><div className="admin-form-actions"><button className="primary-button" type="submit"><AdminIcon name="save" size={16} /> حفظ</button>{editingTable && <button className="secondary-button" type="button" onClick={() => { setEditingTable(null); setTableName(""); }}>إلغاء</button>}</div></form></section><section className="admin-panel"><div className="admin-panel-heading"><div><h2>الطاولات</h2></div><span className="history-count">{formatNumber(snapshot?.tables.length ?? 0)}</span></div><div className="table-manager-list">{snapshot?.tables.map((table) => <div className="table-manager-row" key={table.id}><span className="admin-table-icon"><AdminIcon name="tables" size={17} /></span><strong>{table.name}</strong><span className={`order-status ${table.active ? "paid" : "cancelled"}`}>{table.active ? "نشطة" : "مخفية"}</span><button className="icon-action-button" type="button" aria-label="تعديل الطاولة" onClick={() => { setEditingTable(table.id); setTableName(table.name); }}><AdminIcon name="edit" size={14} /></button><button className="icon-action-button danger" type="button" aria-label="حذف الطاولة" onClick={() => { if (window.confirm(`حذف ${table.name}؟`)) void deleteTable(table.id).then(() => showToast("تم حذف الطاولة")).catch((error: unknown) => showToast(error instanceof Error ? error.message : "تعذر حذف الطاولة")); }}><AdminIcon name="trash" size={14} /></button></div>)}</div></section></div>}

      {activeTab === "invoices" && <section className="admin-panel management-panel"><div className="admin-panel-heading"><div><h2>الفواتير</h2></div><span className="history-count">{formatNumber(filteredInvoices.length)} فاتورة</span></div><div className="management-toolbar invoice-toolbar"><label className="search-field management-search"><AdminIcon name="search" size={17} /><input placeholder="بحث برقم الفاتورة أو اسم العميل" value={invoiceQuery} onChange={(event) => setInvoiceQuery(event.target.value)} /></label><label className="date-filter">من<input type="date" value={invoiceFrom} onChange={(event) => setInvoiceFrom(event.target.value)} /></label><label className="date-filter">إلى<input type="date" value={invoiceTo} onChange={(event) => setInvoiceTo(event.target.value)} /></label><select className="management-select" value={invoiceStatus} onChange={(event) => setInvoiceStatus(event.target.value)}><option value="all">كل الحالات</option><option value="paid">مدفوعة</option><option value="cancelled">ملغاة</option></select></div><div className="orders-table-wrap admin-invoices-wrap"><table className="orders-table"><thead><tr><th>الفاتورة</th><th>العميل</th><th>الكاشير</th><th>الوقت</th><th>الدفع</th><th>الصافي</th><th>الحالة</th><th>الإجراءات</th></tr></thead><tbody>{filteredInvoices.map((order) => <tr key={order.id}><td><strong className="receipt-number">{order.receiptNumber}</strong></td><td>{order.customerName || orderTypeName(order.orderType)}</td><td>{order.cashier}</td><td>{formatDateTime(order.createdAt)}</td><td>{order.paymentMethod === "cash" ? "نقدي" : order.paymentMethod === "card" ? "بطاقة" : "محفظة"}</td><td><strong>{formatMoney(order.total)}</strong></td><td><span className={`order-status ${order.status}`}>{order.status === "paid" ? "مدفوعة" : "ملغاة"}</span></td><td><div className="invoice-action-row"><button className="icon-action-button" type="button" aria-label="إعادة طباعة" title="إعادة طباعة" onClick={() => { try { printInvoice(order, settings!); } catch (error) { showToast(error instanceof Error ? error.message : "تعذرت الطباعة"); } }}><AdminIcon name="receipt" size={15} /></button>{order.status === "paid" && <button className="icon-action-button danger" type="button" aria-label="إلغاء الفاتورة" title="إلغاء الفاتورة" onClick={() => { setCancelTarget(order); setCancelReason(""); }}><AdminIcon name="close" size={15} /></button>}</div></td></tr>)}</tbody></table>{filteredInvoices.length === 0 && <div className="management-empty">لا توجد فواتير</div>}</div><div className="mobile-invoice-list">{filteredInvoices.map((order) => <article className="mobile-invoice-card" key={order.id}><div className="mobile-invoice-head"><strong>{order.receiptNumber}</strong><span className={`order-status ${order.status}`}>{order.status === "paid" ? "مدفوعة" : "ملغاة"}</span></div><div className="mobile-invoice-meta">{order.customerName || orderTypeName(order.orderType)} · {order.cashier}<br />{formatDateTime(order.createdAt)} · {order.paymentMethod === "cash" ? "نقدي" : order.paymentMethod === "card" ? "بطاقة" : "محفظة"}</div><div className="mobile-invoice-actions"><strong>{formatMoney(order.total)}</strong><button className="secondary-button" type="button" onClick={() => { try { printInvoice(order, settings!); } catch (error) { showToast(error instanceof Error ? error.message : "تعذرت الطباعة"); } }}><AdminIcon name="receipt" size={14} /> طباعة</button>{order.status === "paid" && <button className="secondary-button danger-text" type="button" onClick={() => { setCancelTarget(order); setCancelReason(""); }}><AdminIcon name="close" size={14} /> إلغاء</button>}</div></article>)}</div></section>}

      {activeTab === "reports" && <section className="admin-panel management-panel"><div className="admin-panel-heading"><div><h2>التقارير</h2></div><button className="secondary-button" type="button" onClick={exportReportCsv}><AdminIcon name="download" size={15} /> تصدير CSV</button></div><div className="report-period-control">{(["day", "week", "month", "custom"] as const).map((period) => <button type="button" key={period} className={`category-chip ${reportPeriod === period ? "selected" : ""}`} onClick={() => setReportPeriod(period)}>{period === "day" ? "اليوم" : period === "week" ? "الأسبوع" : period === "month" ? "الشهر" : "فترة مخصصة"}</button>)}{reportPeriod === "custom" && <><label className="date-filter">من<input type="date" value={reportFrom} onChange={(event) => setReportFrom(event.target.value)} /></label><label className="date-filter">إلى<input type="date" value={reportTo} onChange={(event) => setReportTo(event.target.value)} /></label></>}</div><div className="report-summary-grid"><article className="report-summary-card"><span>صافي المبيعات</span><strong>{formatMoney(reportRevenue)}</strong></article><article className="report-summary-card"><span>الفواتير المدفوعة</span><strong>{formatNumber(reportOrders.length)}</strong></article><article className="report-summary-card"><span>متوسط الفاتورة</span><strong>{formatMoney(reportOrders.length ? Math.round(reportRevenue / reportOrders.length) : 0)}</strong></article></div><div className="admin-report-grid"><section className="admin-panel report-subpanel"><div className="admin-panel-heading"><div><h2>الأكثر مبيعاً</h2></div></div>{bestSellers.length ? <div className="report-table-list">{bestSellers.map((item, index) => <div className="report-data-row" key={item.name}><span className="category-order-number">{formatNumber(index + 1)}</span><strong>{item.name}</strong><span>{formatNumber(item.quantity)} قطعة</span><b>{formatMoney(item.revenue)}</b></div>)}</div> : <div className="management-empty">لا توجد مبيعات في الفترة المحددة</div>}</section><section className="admin-panel report-subpanel"><div className="admin-panel-heading"><div><h2>طرق التحصيل</h2></div></div><div className="report-table-list">{paymentTotals.length ? paymentTotals.map(([method, total]) => <div className="report-data-row" key={method}><strong>{method === "cash" ? "نقدي" : method === "card" ? "بطاقة" : "محفظة"}</strong><span>{formatNumber(total.count)} فاتورة</span><b>{formatMoney(total.amount)}</b></div>) : <div className="management-empty">لا توجد بيانات</div>}</div></section><section className="admin-panel report-subpanel"><div className="admin-panel-heading"><div><h2>أداء الكاشيرات</h2></div></div><div className="report-table-list">{cashierTotals.length ? cashierTotals.map((cashier) => <div className="report-data-row" key={cashier.name}><strong>{cashier.name}</strong><span>{formatNumber(cashier.count)} فاتورة</span><b>{formatMoney(cashier.amount)}</b></div>) : <div className="management-empty">لا توجد بيانات</div>}</div></section></div></section>}

      {activeTab === "users" && <section className="admin-panel management-panel"><div className="admin-panel-heading"><div><h2>المستخدمون</h2></div><button className="primary-button" type="button" onClick={() => { setUserDraft(emptyUser); setUserModal(true); }}><AdminIcon name="plus" size={16} /> إضافة مستخدم</button></div><div className="user-manager-list">{users.map((user) => <div className="user-manager-row" key={user.id}><span className="user-manager-avatar">{user.name.slice(0, 1)}</span><span className="user-manager-name"><strong>{user.name}</strong><small>{user.username}</small></span><span className={`user-role-tag ${user.role}`}>{user.role === "manager" ? "مدير" : "كاشير"}</span><span className={`order-status ${user.active ? "paid" : "cancelled"}`}>{user.active ? "نشط" : "موقوف"}</span><div className="invoice-action-row"><button className="icon-action-button" type="button" aria-label="تعديل المستخدم" onClick={() => { setUserDraft({ id: user.id, name: user.name, username: user.username, role: user.role, password: "", active: user.active }); setUserModal(true); }}><AdminIcon name="edit" size={15} /></button><button className="icon-action-button" type="button" aria-label={user.active ? "إيقاف المستخدم" : "تفعيل المستخدم"} onClick={() => void toggleUserActivation(user).catch((error: unknown) => showToast(error instanceof Error ? error.message : "تعذر تحديث المستخدم"))}><AdminIcon name={user.active ? "eyeOff" : "eye"} size={15} /></button><button className="icon-action-button danger" type="button" aria-label="حذف المستخدم" onClick={() => void removeUserAccount(user).catch((error: unknown) => showToast(error instanceof Error ? error.message : "تعذر حذف المستخدم"))}><AdminIcon name="trash" size={15} /></button></div></div>)}</div></section>}

      {activeTab === "settings" && settingsDraft && <div className="admin-settings-stack"><form className="admin-panel settings-form" onSubmit={(event) => void saveSettingsForm(event)}><div className="admin-panel-heading"><div><h2>إعدادات المطعم</h2></div><button className="primary-button" type="submit"><AdminIcon name="save" size={16} /> حفظ الإعدادات</button></div><div className="settings-form-grid"><label>اسم المطعم<input value={settingsDraft.restaurantName} onChange={(event) => { setSettingsDraft({ ...settingsDraft, restaurantName: event.target.value }); setSettingsDirty(true); }} required /></label><label>العنوان<input value={settingsDraft.address} onChange={(event) => { setSettingsDraft({ ...settingsDraft, address: event.target.value }); setSettingsDirty(true); }} /></label><label>التليفون<input type="tel" value={settingsDraft.phone} onChange={(event) => { setSettingsDraft({ ...settingsDraft, phone: event.target.value }); setSettingsDirty(true); }} /></label><label>الرقم الضريبي<input value={settingsDraft.taxNumber} onChange={(event) => { setSettingsDraft({ ...settingsDraft, taxNumber: event.target.value }); setSettingsDirty(true); }} /></label><label>ضريبة القيمة المضافة (%)<input type="number" min="0" max="100" step="0.1" value={settingsDraft.taxRate} onChange={(event) => { setSettingsDraft({ ...settingsDraft, taxRate: Number(event.target.value) }); setSettingsDirty(true); }} /></label><label>الخدمة (%)<input type="number" min="0" max="100" step="0.1" value={settingsDraft.serviceRate} onChange={(event) => { setSettingsDraft({ ...settingsDraft, serviceRate: Number(event.target.value) }); setSettingsDirty(true); }} /></label><label>رسوم التوصيل (ج.م)<input type="number" min="0" step="1" value={settingsDraft.deliveryFee} onChange={(event) => { setSettingsDraft({ ...settingsDraft, deliveryFee: Number(event.target.value) }); setSettingsDirty(true); }} /></label><label className="settings-wide-field">رسالة أسفل الإيصال<input value={settingsDraft.receiptMessage} onChange={(event) => { setSettingsDraft({ ...settingsDraft, receiptMessage: event.target.value }); setSettingsDirty(true); }} /></label></div><div className="logo-settings-section"><div><h3>شعار المطعم</h3><p>PNG أو SVG أو JPG</p></div><div className="logo-upload-row"><div className="logo-preview-box"><RestaurantLogo logo={settingsDraft.logo} name={settingsDraft.restaurantName} iconClass="settings-logo-icon" size={27} /></div><label className="secondary-button upload-control"><AdminIcon name="upload" size={15} /> رفع شعار المطعم<input type="file" accept="image/png,image/jpeg,image/svg+xml,image/webp" onChange={(event) => { void uploadRestaurantLogo(event.target.files?.[0]); event.target.value = ""; }} /></label><button className="secondary-button" type="button" onClick={() => { if (settingsDraft.logo && window.confirm("حذف شعار المطعم؟")) { setSettingsDraft({ ...settingsDraft, logo: "" }); setSettingsDirty(true); } }}>حذف الشعار</button></div><label className="logo-url-label">أو لصق رابط الصورة<input type="url" dir="ltr" value={logoUrl} onChange={(event) => setLogoUrl(event.target.value)} placeholder="https://" onBlur={() => { if (logoUrl.trim()) { setSettingsDraft({ ...settingsDraft, logo: logoUrl.trim() }); setSettingsDirty(true); } }} /></label></div></form>
        <div className="admin-two-column"><section className="admin-panel settings-form"><div className="admin-panel-heading"><div><h2>تغيير كلمة المرور</h2></div></div><form className="admin-form" onSubmit={(event) => void saveManagerPassword(event)}><label>كلمة المرور الحالية<input type="password" autoComplete="current-password" value={currentPassword} onChange={(event) => setCurrentPassword(event.target.value)} required /></label><label>كلمة المرور الجديدة<input type="password" autoComplete="new-password" minLength={6} value={accountNewPassword} onChange={(event) => setAccountNewPassword(event.target.value)} required /></label><label>تأكيد كلمة المرور<input type="password" autoComplete="new-password" minLength={6} value={accountConfirmPassword} onChange={(event) => setAccountConfirmPassword(event.target.value)} required /></label><button className="primary-button" type="submit"><AdminIcon name="lock" size={15} /> تحديث كلمة المرور</button></form></section><section className="admin-panel settings-form"><div className="admin-panel-heading"><div><h2>حساب المدير</h2></div></div><div className="manager-account-summary"><span className="user-manager-avatar">{manager.name.slice(0, 1)}</span><div><strong>{manager.name}</strong><small>{manager.username} · مدير</small></div></div></section></div>
      </div>}

      {activeTab === "backup" && <div className="admin-two-column"><section className="admin-panel backup-action-card"><span className="backup-card-icon"><AdminIcon name="download" size={21} /></span><h2>تصدير نسخة احتياطية</h2><button className="primary-button" type="button" onClick={() => void downloadBackup()}><AdminIcon name="download" size={16} /> تنزيل النسخة</button></section><section className="admin-panel backup-action-card"><span className="backup-card-icon"><AdminIcon name="upload" size={21} /></span><h2>استيراد نسخة احتياطية</h2><label className="secondary-button upload-control"><AdminIcon name="upload" size={16} /> اختيار ملف JSON<input type="file" accept="application/json,.json" onChange={(event) => { void uploadBackup(event.target.files?.[0]); event.target.value = ""; }} /></label></section><section className="admin-panel backup-danger-card"><span className="backup-card-icon danger-icon"><AdminIcon name="trash" size={20} /></span><h2>تصفير البيانات</h2><button className="danger-button" type="button" onClick={() => void resetDemoData()}><AdminIcon name="trash" size={15} /> تصفير البيانات</button></section></div>}
    </div>

    {productModal && <div className="modal-backdrop" role="presentation" onMouseDown={() => setProductModal(false)}><section className="admin-edit-modal" role="dialog" aria-modal="true" aria-labelledby="product-modal-title" onMouseDown={(event) => event.stopPropagation()}><div className="admin-modal-heading"><h2 id="product-modal-title">{productDraft.id ? "تعديل الصنف" : "إضافة صنف"}</h2><button className="icon-action-button" type="button" aria-label="إغلاق" onClick={() => setProductModal(false)}><AdminIcon name="close" size={17} /></button></div><form className="admin-form" onSubmit={(event) => void saveProductForm(event)}><div className="edit-product-grid"><label>اسم الصنف<input value={productDraft.name} onChange={(event) => setProductDraft({ ...productDraft, name: event.target.value })} required /></label><label>القسم<select value={productDraft.category} onChange={(event) => setProductDraft({ ...productDraft, category: event.target.value })} required>{categories.map((category) => <option key={category.id} value={category.name}>{category.name}</option>)}</select></label><label>السعر (ج.م)<input type="number" min="0" step="1" value={productDraft.price} onChange={(event) => setProductDraft({ ...productDraft, price: event.target.value })} required /></label><label>الشارة<select value={productDraft.badge} onChange={(event) => setProductDraft({ ...productDraft, badge: event.target.value })}><option value="">بدون شارة</option><option value="الأكثر طلباً">الأكثر طلباً</option><option value="جديد">جديد</option></select></label><label className="edit-product-full">الوصف<input value={productDraft.description} onChange={(event) => setProductDraft({ ...productDraft, description: event.target.value })} /></label><label className="edit-product-full">رابط الصورة<input type="url" dir="ltr" value={productDraft.image.startsWith("data:") ? "" : productDraft.image} placeholder="https://" onChange={(event) => setProductDraft({ ...productDraft, image: event.target.value })} /></label><div className="edit-product-full photo-preview-area"><div className="photo-preview"><DishImage src={productDraft.image} name={productDraft.name || "الصنف"} /></div><label className="secondary-button upload-control"><AdminIcon name="upload" size={15} /> رفع صورة من الجهاز<input type="file" accept="image/png,image/jpeg,image/webp" onChange={(event) => { void uploadProductImage(event.target.files?.[0]); event.target.value = ""; }} /></label><label className="admin-checkbox"><input type="checkbox" checked={productDraft.active} onChange={(event) => setProductDraft({ ...productDraft, active: event.target.checked })} /> ظاهر في الكاشير</label></div></div><div className="admin-form-actions"><button className="primary-button" type="submit"><AdminIcon name="save" size={16} /> حفظ الصنف</button><button className="secondary-button" type="button" onClick={() => setProductModal(false)}>إلغاء</button></div></form></section></div>}

    {userModal && <div className="modal-backdrop" role="presentation" onMouseDown={() => setUserModal(false)}><section className="admin-edit-modal compact-edit-modal" role="dialog" aria-modal="true" aria-labelledby="user-modal-title" onMouseDown={(event) => event.stopPropagation()}><div className="admin-modal-heading"><h2 id="user-modal-title">{userDraft.id ? "تعديل المستخدم" : "إضافة مستخدم"}</h2><button className="icon-action-button" type="button" aria-label="إغلاق" onClick={() => setUserModal(false)}><AdminIcon name="close" size={17} /></button></div><form className="admin-form" onSubmit={(event) => void saveUserForm(event)}><label>الاسم<input value={userDraft.name} onChange={(event) => setUserDraft({ ...userDraft, name: event.target.value })} required /></label><label>اسم المستخدم<input autoComplete="off" value={userDraft.username} onChange={(event) => setUserDraft({ ...userDraft, username: event.target.value })} required /></label><label>الصلاحية<select value={userDraft.role} onChange={(event) => setUserDraft({ ...userDraft, role: event.target.value as UserRole })}><option value="cashier">كاشير</option><option value="manager">مدير</option></select></label><label>كلمة المرور{userDraft.id && <small className="form-hint">اتركها فارغة دون تغيير.</small>}<input type="password" autoComplete="new-password" minLength={6} value={userDraft.password} onChange={(event) => setUserDraft({ ...userDraft, password: event.target.value })} required={!userDraft.id} /></label><label className="admin-checkbox"><input type="checkbox" checked={userDraft.active} onChange={(event) => setUserDraft({ ...userDraft, active: event.target.checked })} /> المستخدم نشط</label><div className="admin-form-actions"><button className="primary-button" type="submit"><AdminIcon name="save" size={16} /> حفظ</button><button className="secondary-button" type="button" onClick={() => setUserModal(false)}>إلغاء</button></div></form></section></div>}

    {forcePasswordChange && <div className="modal-backdrop forced-password-backdrop"><section className="admin-edit-modal compact-edit-modal force-password-card" role="dialog" aria-modal="true" aria-labelledby="forced-password-title"><span className="backup-card-icon"><AdminIcon name="lock" size={22} /></span><h2 id="forced-password-title">تغيير كلمة المرور</h2><p>حدّث كلمة المرور قبل الدخول إلى لوحة الإدارة.</p><form className="admin-form" onSubmit={(event) => void submitForcedPassword(event)}><label>كلمة المرور الجديدة<input type="password" autoComplete="new-password" minLength={6} value={newPassword} onChange={(event) => setNewPassword(event.target.value)} required /></label><label>تأكيد كلمة المرور<input type="password" autoComplete="new-password" minLength={6} value={confirmPassword} onChange={(event) => setConfirmPassword(event.target.value)} required /></label>{loginError && <div className="admin-login-error">{loginError}</div>}<button className="admin-login-submit" type="submit" disabled={loginLoading}>{loginLoading ? "جارٍ الحفظ..." : "تحديث كلمة المرور"}</button></form></section></div>}

    {cancelTarget && <div className="modal-backdrop" role="presentation" onMouseDown={() => setCancelTarget(null)}><section className="admin-edit-modal compact-edit-modal" role="dialog" aria-modal="true" aria-labelledby="cancel-title" onMouseDown={(event) => event.stopPropagation()}><div className="admin-modal-heading"><h2 id="cancel-title">إلغاء الفاتورة {cancelTarget.receiptNumber}</h2><button className="icon-action-button" type="button" aria-label="إغلاق" onClick={() => setCancelTarget(null)}><AdminIcon name="close" size={17} /></button></div><form className="admin-form" onSubmit={(event) => void submitCancelOrder(event)}><label>سبب الإلغاء<textarea value={cancelReason} onChange={(event) => setCancelReason(event.target.value)} rows={3} required /></label><div className="admin-form-actions"><button className="danger-button" type="submit">تأكيد الإلغاء</button><button className="secondary-button" type="button" onClick={() => setCancelTarget(null)}>رجوع</button></div></form></section></div>}
    {toast && <div className="toast-message" role="status"><span><AdminIcon name="check" size={16} /></span>{toast}</div>}
  </main>;
}
