"use client";

import Image from "next/image";
import { useState } from "react";

function DishFallback({ name, className }: { name: string; className: string }) {
  return <span className={`dish-placeholder ${className}`} aria-label={name}><span>{name}</span></span>;
}

function DishSource({ src, name, className, sizes }: { src: string; name: string; className: string; sizes: string }) {
  const [failed, setFailed] = useState(false);
  if (failed) return <DishFallback name={name} className={className} />;
  return <Image src={src} alt={name} fill unoptimized loading="lazy" sizes={sizes} className={className} onError={() => setFailed(true)} />;
}

export function DishImage({ src, name, className = "", sizes }: { src: string; name: string; className?: string; sizes?: string }) {
  if (!src) return <DishFallback name={name} className={className} />;
  return <DishSource key={src} src={src} name={name} className={className} sizes={sizes ?? "(max-width: 700px) 45vw, 220px"} />;
}

function RestaurantLogoSource({ logo, name, className, iconClass, size }: { logo: string; name: string; className: string; iconClass: string; size: number }) {
  const [failed, setFailed] = useState(false);
  if (failed) return <RestaurantLogoFallback name={name} className={className} iconClass={iconClass} size={size} />;
  return <span className={`${iconClass} restaurant-logo ${className}`}><Image src={logo} alt={name} fill unoptimized sizes="96px" className="restaurant-logo-image" onError={() => setFailed(true)} /></span>;
}

function RestaurantLogoFallback({ name, className, iconClass, size }: { name: string; className: string; iconClass: string; size: number }) {
  return <span className={`${iconClass} ${className}`} aria-label={name}><svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M4 13.5h16a8 8 0 0 1-16 0Z"/><path d="M7 9.5a5 5 0 0 1 10 0M12 3v2M4 20h16"/></svg></span>;
}

export function RestaurantLogo({ logo, name, className = "", iconClass = "brand-icon", size = 25 }: { logo?: string; name: string; className?: string; iconClass?: string; size?: number }) {
  if (!logo) return <RestaurantLogoFallback name={name} className={className} iconClass={iconClass} size={size} />;
  return <RestaurantLogoSource key={logo} logo={logo} name={name} className={className} iconClass={iconClass} size={size} />;
}

export function setRestaurantFavicon(logo: string, restaurantName = "مذاق البلد") {
  if (typeof document === "undefined") return;
  document.title = restaurantName;
  let description = document.querySelector<HTMLMetaElement>('meta[name="description"]');
  if (!description) {
    description = document.createElement("meta");
    description.name = "description";
    document.head.appendChild(description);
  }
  description.content = restaurantName;
  let icon = document.querySelector<HTMLLinkElement>('link[rel="icon"]');
  if (!icon) {
    icon = document.createElement("link");
    icon.rel = "icon";
    document.head.appendChild(icon);
  }
  icon.href = logo || "data:image/svg+xml," + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40"><rect width="40" height="40" rx="12" fill="#e97840"/><path d="M8 22h24a12 12 0 0 1-24 0Zm4-6a8 8 0 0 1 16 0m-8-8v4" fill="none" stroke="white" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>');
}
