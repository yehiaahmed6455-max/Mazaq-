export const NUMBER_LOCALE = "en-GB";

export function formatNumber(value: number, maximumFractionDigits = 0) {
  return new Intl.NumberFormat(NUMBER_LOCALE, { maximumFractionDigits }).format(Number.isFinite(value) ? value : 0);
}

export function formatMoney(value: number) {
  return `${formatNumber(value)} ج.م`;
}

export function formatDateTime(value: string | Date, includeYear = true) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return new Intl.DateTimeFormat(NUMBER_LOCALE, {
    day: "2-digit",
    month: "2-digit",
    ...(includeYear ? { year: "numeric" } : {}),
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).format(date);
}

export function formatDate(value: string | Date) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return new Intl.DateTimeFormat(NUMBER_LOCALE, { day: "2-digit", month: "2-digit", year: "numeric" }).format(date);
}

export function toIsoDate(value: Date) {
  const year = value.getFullYear();
  const month = String(value.getMonth() + 1).padStart(2, "0");
  const day = String(value.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export function dateRangeFor(value: "day" | "week" | "month", now = new Date()) {
  const start = new Date(now);
  if (value === "day") start.setHours(0, 0, 0, 0);
  if (value === "week") {
    start.setDate(start.getDate() - ((start.getDay() + 6) % 7));
    start.setHours(0, 0, 0, 0);
  }
  if (value === "month") {
    start.setDate(1);
    start.setHours(0, 0, 0, 0);
  }
  const end = new Date(now);
  end.setHours(23, 59, 59, 999);
  return { start, end };
}
