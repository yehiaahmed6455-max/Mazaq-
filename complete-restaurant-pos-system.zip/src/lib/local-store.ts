import { MENU, MENU_CATEGORIES, type MenuProduct } from "@/lib/menu";

export type UserRole = "manager" | "cashier";
export type RestaurantUser = {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  salt: string;
  passwordHash: string;
  mustChangePassword: boolean;
  active: boolean;
};

export type RestaurantSettings = {
  id: "main";
  restaurantName: string;
  address: string;
  phone: string;
  taxNumber: string;
  taxRate: number;
  serviceRate: number;
  deliveryFee: number;
  receiptMessage: string;
  logo: string;
};

export type RestaurantCategory = { id: string; name: string; sortOrder: number };
export type RestaurantTable = { id: string; name: string; active: boolean };
export type OrderItem = {
  productId: string;
  name: string;
  quantity: number;
  unitPrice: number;
  lineTotal: number;
};
export type RestaurantOrder = {
  id: number;
  sequence: number;
  receiptNumber: string;
  cashierId: string;
  cashier: string;
  orderType: "dine-in" | "takeaway" | "delivery";
  tableLabel: string | null;
  customerName: string | null;
  paymentMethod: "cash" | "card" | "wallet";
  subtotal: number;
  discount: number;
  tax: number;
  service: number;
  deliveryFee: number;
  total: number;
  cashReceived: number;
  changeDue: number;
  notes: string;
  items: OrderItem[];
  status: "paid" | "cancelled";
  cancelReason: string;
  cancelledBy: string;
  createdAt: string;
};

export type DataSnapshot = {
  products: MenuProduct[];
  categories: RestaurantCategory[];
  tables: RestaurantTable[];
  users: RestaurantUser[];
  settings: RestaurantSettings;
  orders: RestaurantOrder[];
};

export const STORE_NAMES = ["products", "categories", "tables", "users", "settings", "orders", "audit"] as const;
type StoreName = (typeof STORE_NAMES)[number];
const DB_NAME = "mazaq-elbalad-pos";
const DB_VERSION = 1;
const CHANGE_EVENT = "mazaq-local-db-change";
const listeners = new Set<() => void>();
let databasePromise: Promise<IDBDatabase> | null = null;
let syncChannel: BroadcastChannel | null = null;
let initializationPromise: Promise<void> | null = null;

export const DEFAULT_SETTINGS: RestaurantSettings = {
  id: "main",
  restaurantName: "مذاق البلد",
  address: "",
  phone: "",
  taxNumber: "",
  taxRate: 14,
  serviceRate: 12,
  deliveryFee: 35,
  receiptMessage: "شكراً لزيارتكم",
  logo: "",
};

function openDatabase(): Promise<IDBDatabase> {
  if (typeof window === "undefined") return Promise.reject(new Error("مخزن المتصفح غير متاح"));
  if (databasePromise) return databasePromise;

  databasePromise = new Promise((resolve, reject) => {
    const request = window.indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains("products")) database.createObjectStore("products", { keyPath: "id" });
      if (!database.objectStoreNames.contains("categories")) database.createObjectStore("categories", { keyPath: "id" });
      if (!database.objectStoreNames.contains("tables")) database.createObjectStore("tables", { keyPath: "id" });
      if (!database.objectStoreNames.contains("users")) database.createObjectStore("users", { keyPath: "id" });
      if (!database.objectStoreNames.contains("settings")) database.createObjectStore("settings", { keyPath: "id" });
      if (!database.objectStoreNames.contains("orders")) database.createObjectStore("orders", { keyPath: "id", autoIncrement: true });
      if (!database.objectStoreNames.contains("audit")) database.createObjectStore("audit", { keyPath: "id", autoIncrement: true });
    };
    request.onsuccess = () => {
      request.result.onversionchange = () => {
        request.result.close();
        databasePromise = null;
      };
      resolve(request.result);
    };
    request.onerror = () => {
      databasePromise = null;
      reject(request.error ?? new Error("تعذر فتح قاعدة البيانات"));
    };
  });
  return databasePromise;
}

function requestResult<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("تعذر تنفيذ العملية"));
  });
}

function transactionComplete(transaction: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onabort = () => reject(transaction.error ?? new Error("تم إلغاء العملية"));
    transaction.onerror = () => reject(transaction.error ?? new Error("تعذر حفظ البيانات"));
  });
}

function openSyncChannel() {
  if (typeof window === "undefined" || typeof BroadcastChannel === "undefined") return;
  if (!syncChannel) {
    syncChannel = new BroadcastChannel("mazaq-indexeddb-sync");
    syncChannel.onmessage = () => {
      for (const listener of listeners) listener();
    };
  }
}

export function publishDataChange() {
  if (typeof window === "undefined") return;
  openSyncChannel();
  window.dispatchEvent(new Event(CHANGE_EVENT));
  syncChannel?.postMessage(Date.now());
}

export function subscribeToDataChanges(listener: () => void) {
  listeners.add(listener);
  openSyncChannel();
  window.addEventListener(CHANGE_EVENT, listener);
  return () => {
    listeners.delete(listener);
    window.removeEventListener(CHANGE_EVENT, listener);
  };
}

function randomSalt() {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return [...bytes].map((value) => value.toString(16).padStart(2, "0")).join("");
}

function bytesToHex(bytes: Uint8Array) {
  return [...bytes].map((value) => value.toString(16).padStart(2, "0")).join("");
}

async function passwordHash(password: string, salt: string) {
  const saltBytes = new Uint8Array(salt.match(/.{1,2}/g)?.map((byte) => Number.parseInt(byte, 16)) ?? []);
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt: saltBytes, iterations: 210_000, hash: "SHA-256" }, key, 256);
  return bytesToHex(new Uint8Array(bits));
}

export async function hashNewPassword(password: string) {
  if (password.length < 6) throw new Error("كلمة المرور يجب ألا تقل عن 6 أحرف");
  const salt = randomSalt();
  return { salt, passwordHash: await passwordHash(password, salt) };
}

function newUser(id: string, username: string, name: string, role: UserRole, salt: string, passwordHashValue: string, mustChangePassword = false): RestaurantUser {
  return { id, username, name, role, salt, passwordHash: passwordHashValue, mustChangePassword, active: true };
}

function orderSeed(
  sequence: number,
  cashierId: string,
  cashier: string,
  name: string,
  ageMinutes: number,
  items: [string, number][], 
  method: RestaurantOrder["paymentMethod"],
  orderType: RestaurantOrder["orderType"],
  tableLabel: string | null,
): RestaurantOrder {
  const lineItems: OrderItem[] = items.map(([id, quantity]) => {
    const product = MENU.find((item) => item.id === id)!;
    return { productId: product.id, name: product.name, quantity, unitPrice: product.price, lineTotal: quantity * product.price };
  });
  const subtotal = lineItems.reduce((sum, item) => sum + item.lineTotal, 0);
  const tax = Math.round(subtotal * DEFAULT_SETTINGS.taxRate / 100);
  const service = orderType === "dine-in" ? Math.round(subtotal * DEFAULT_SETTINGS.serviceRate / 100) : 0;
  const created = new Date(Date.now() - ageMinutes * 60_000);
  const total = subtotal + tax + service;
  return {
    id: sequence,
    sequence,
    receiptNumber: `#${String(sequence).padStart(4, "0")}`,
    cashierId,
    cashier,
    orderType,
    tableLabel,
    customerName: name,
    paymentMethod: method,
    subtotal,
    discount: 0,
    tax,
    service,
    deliveryFee: 0,
    total,
    cashReceived: method === "cash" ? total + 20 : total,
    changeDue: method === "cash" ? 20 : 0,
    notes: "",
    items: lineItems,
    status: "paid",
    cancelReason: "",
    cancelledBy: "",
    createdAt: created.toISOString(),
  };
}

async function seedDatabase(database: IDBDatabase) {
  const read = database.transaction(["products", "users", "settings"], "readonly");
  const [products, users, settings] = await Promise.all([
    requestResult(read.objectStore("products").getAll() as IDBRequest<MenuProduct[]>),
    requestResult(read.objectStore("users").getAll() as IDBRequest<RestaurantUser[]>),
    requestResult(read.objectStore("settings").getAll() as IDBRequest<RestaurantSettings[]>),
  ]);
  await transactionComplete(read);

  const firstRun = products.length === 0 && users.length === 0 && settings.length === 0;
  const seedUsers: RestaurantUser[] = firstRun ? [
    newUser("manager-default", "admin", "مدير المطعم", "manager", "fc8a8b1631a4d66420d1965e104bddb2", "de1822f357cf99b873ad4ab1766c47c50f3cd8caf4c8d83758894e84064fd4e4", true),
    newUser("cashier-somaya", "somaya", "سمية حسن", "cashier", "dd85244dad12411b18b256c716a6db65", "0b4a74f7cab720f77c553a5803ac1069524a4250b63e6c6907fbe95fed4790b7"),
    newUser("cashier-mohamed", "mohamed", "محمد علي", "cashier", "adaf35e669a0894620214b69d9a74cac", "84f884b557cf2ad721ef53f208942effe6d624764ac8ab833c4af8c8ff1d0ace"),
    newUser("cashier-noha", "noha", "نهى محمود", "cashier", "f5c2446b4d20fa7356b7607588b46ceb", "46f1edd52560fde8ce4d6e8db4142e3ea1b3b26c42394b5aec0e3c19241324d4"),
  ] : [];

  const write = database.transaction([...STORE_NAMES], "readwrite");
  const productStore = write.objectStore("products");
  const categoryStore = write.objectStore("categories");
  const tableStore = write.objectStore("tables");
  const userStore = write.objectStore("users");
  const settingsStore = write.objectStore("settings");
  const orderStore = write.objectStore("orders");
  if (firstRun) for (const product of MENU) productStore.put(product);
  if (firstRun) {
    MENU_CATEGORIES.filter((name) => name !== "الكل").forEach((name, index) => categoryStore.put({ id: name, name, sortOrder: index } satisfies RestaurantCategory));
  }
  if (seedUsers.length) for (const user of seedUsers) userStore.put(user);
  if (firstRun) settingsStore.put({ ...DEFAULT_SETTINGS, id: "main" });
  if (firstRun) {
    for (let index = 1; index <= 12; index += 1) tableStore.put({ id: `table-${index}`, name: `طاولة ${index}`, active: true } satisfies RestaurantTable);
  }
  if (firstRun) {
    const samples = [
        orderSeed(1, "cashier-somaya", "سمية حسن", "أحمد مصطفى", 150, [["dish-001", 1], ["dish-060", 1]], "cash", "dine-in", "طاولة 3"),
        orderSeed(2, "cashier-mohamed", "محمد علي", "منى إبراهيم", 90, [["dish-013", 2], ["dish-074", 2]], "card", "takeaway", null),
        orderSeed(3, "cashier-noha", "نهى محمود", "كريم السيد", 30, [["dish-007", 1], ["dish-055", 1]], "wallet", "dine-in", "طاولة 5"),
      ];
    for (const order of samples) orderStore.put(order);
  }
  await transactionComplete(write);
}

export async function ensureLocalStore() {
  if (!initializationPromise) {
    initializationPromise = (async () => {
      const database = await openDatabase();
      await seedDatabase(database);
    })().catch((error) => {
      initializationPromise = null;
      throw error;
    });
  }
  await initializationPromise;
}

async function allFromStore<T>(name: StoreName): Promise<T[]> {
  await ensureLocalStore();
  const database = await openDatabase();
  const transaction = database.transaction(name, "readonly");
  const result = await requestResult(transaction.objectStore(name).getAll() as IDBRequest<T[]>);
  await transactionComplete(transaction);
  return result;
}

export async function readProducts() {
  return (await allFromStore<MenuProduct>("products")).filter((product) => product.active !== false);
}

export async function readAllProducts() {
  return allFromStore<MenuProduct>("products");
}

export async function readCategories() {
  return (await allFromStore<RestaurantCategory>("categories")).sort((a, b) => a.sortOrder - b.sortOrder);
}

export async function readTables() {
  return (await allFromStore<RestaurantTable>("tables")).filter((table) => table.active);
}

export async function readUsers() {
  return (await allFromStore<RestaurantUser>("users")).sort((a, b) => a.name.localeCompare(b.name, "ar"));
}

export async function readOrders() {
  return (await allFromStore<RestaurantOrder>("orders")).sort((a, b) => b.sequence - a.sequence);
}

export async function readSettings(): Promise<RestaurantSettings> {
  const settings = await allFromStore<RestaurantSettings>("settings");
  return settings.find((value) => value.id === "main") ?? { ...DEFAULT_SETTINGS };
}

export async function readSnapshot(): Promise<DataSnapshot> {
  await ensureLocalStore();
  const database = await openDatabase();
  const transaction = database.transaction(["products", "categories", "tables", "users", "settings", "orders"], "readonly");
  const snapshot = await Promise.all([
    requestResult(transaction.objectStore("products").getAll() as IDBRequest<MenuProduct[]>),
    requestResult(transaction.objectStore("categories").getAll() as IDBRequest<RestaurantCategory[]>),
    requestResult(transaction.objectStore("tables").getAll() as IDBRequest<RestaurantTable[]>),
    requestResult(transaction.objectStore("users").getAll() as IDBRequest<RestaurantUser[]>),
    requestResult(transaction.objectStore("settings").get("main") as IDBRequest<RestaurantSettings | undefined>),
    requestResult(transaction.objectStore("orders").getAll() as IDBRequest<RestaurantOrder[]>),
  ]);
  await transactionComplete(transaction);
  return {
    products: snapshot[0],
    categories: snapshot[1].sort((a, b) => a.sortOrder - b.sortOrder),
    tables: snapshot[2],
    users: snapshot[3],
    settings: snapshot[4] ?? { ...DEFAULT_SETTINGS },
    orders: snapshot[5].sort((a, b) => b.sequence - a.sequence),
  };
}

export async function verifyUser(username: string, password: string, role?: UserRole) {
  const users = await readUsers();
  const user = users.find((entry) => entry.active && entry.username.toLocaleLowerCase() === username.trim().toLocaleLowerCase() && (!role || entry.role === role));
  if (!user) return null;
  const candidate = await passwordHash(password, user.salt);
  let difference = candidate.length ^ user.passwordHash.length;
  for (let index = 0; index < Math.max(candidate.length, user.passwordHash.length); index += 1) {
    difference |= (candidate.charCodeAt(index) || 0) ^ (user.passwordHash.charCodeAt(index) || 0);
  }
  return difference === 0 ? user : null;
}

export async function saveProduct(product: MenuProduct) {
  await ensureLocalStore();
  const database = await openDatabase();
  const transaction = database.transaction("products", "readwrite");
  transaction.objectStore("products").put(product);
  await transactionComplete(transaction);
  publishDataChange();
}

export async function deleteProduct(id: string) {
  await ensureLocalStore();
  const database = await openDatabase();
  const transaction = database.transaction("products", "readwrite");
  transaction.objectStore("products").delete(id);
  await transactionComplete(transaction);
  publishDataChange();
}

export async function saveCategory(category: RestaurantCategory) {
  await ensureLocalStore();
  const database = await openDatabase();
  const transaction = database.transaction("categories", "readwrite");
  transaction.objectStore("categories").put(category);
  await transactionComplete(transaction);
  publishDataChange();
}

export async function renameCategory(id: string, name: string) {
  const categories = await readCategories();
  const current = categories.find((category) => category.id === id);
  const cleanName = name.trim();
  if (!current || !cleanName) throw new Error("اكتب اسم القسم");
  if (categories.some((category) => category.id !== id && category.name.toLocaleLowerCase() === cleanName.toLocaleLowerCase())) throw new Error("اسم القسم مستخدم بالفعل");
  const products = await readAllProducts();
  const database = await openDatabase();
  const transaction = database.transaction(["categories", "products"], "readwrite");
  transaction.objectStore("categories").delete(id);
  transaction.objectStore("categories").put({ ...current, id: cleanName, name: cleanName });
  for (const product of products) if (product.category === current.name) transaction.objectStore("products").put({ ...product, category: cleanName });
  await transactionComplete(transaction);
  publishDataChange();
}

export async function deleteCategory(id: string) {
  const [products, categories] = await Promise.all([readAllProducts(), readCategories()]);
  const category = categories.find((entry) => entry.id === id);
  if (category && products.some((product) => product.category === category.name)) throw new Error("انقل الأصناف لقسم آخر قبل حذف القسم");
  await ensureLocalStore();
  const database = await openDatabase();
  const transaction = database.transaction("categories", "readwrite");
  transaction.objectStore("categories").delete(id);
  await transactionComplete(transaction);
  publishDataChange();
}

export async function reorderCategories(categories: RestaurantCategory[]) {
  await ensureLocalStore();
  const database = await openDatabase();
  const transaction = database.transaction("categories", "readwrite");
  categories.forEach((category, index) => transaction.objectStore("categories").put({ ...category, sortOrder: index }));
  await transactionComplete(transaction);
  publishDataChange();
}

export async function saveTable(table: RestaurantTable) {
  await ensureLocalStore();
  const database = await openDatabase();
  const transaction = database.transaction("tables", "readwrite");
  transaction.objectStore("tables").put(table);
  await transactionComplete(transaction);
  publishDataChange();
}

export async function deleteTable(id: string) {
  await ensureLocalStore();
  const database = await openDatabase();
  const transaction = database.transaction("tables", "readwrite");
  transaction.objectStore("tables").delete(id);
  await transactionComplete(transaction);
  publishDataChange();
}

export async function saveSettings(settings: RestaurantSettings) {
  await ensureLocalStore();
  const database = await openDatabase();
  const transaction = database.transaction("settings", "readwrite");
  transaction.objectStore("settings").put({ ...settings, id: "main" });
  await transactionComplete(transaction);
  publishDataChange();
}

export async function saveUser(user: RestaurantUser, password?: string) {
  await ensureLocalStore();
  const users = await readUsers();
  const username = user.username.trim();
  const name = user.name.trim();
  if (!username || !name) throw new Error("اسم المستخدم والاسم مطلوبان");
  const duplicate = users.some((entry) => entry.id !== user.id && entry.username.toLowerCase() === username.toLowerCase());
  if (duplicate) throw new Error("اسم المستخدم مستخدم بالفعل");
  const currentUser = users.find((entry) => entry.id === user.id);
  const otherActiveManagers = users.filter((entry) => entry.id !== user.id && entry.role === "manager" && entry.active);
  if (currentUser?.role === "manager" && currentUser.active && (user.role !== "manager" || !user.active) && otherActiveManagers.length === 0) {
    throw new Error("لا يمكن إيقاف أو تغيير دور المدير الوحيد");
  }
  let nextUser = { ...user, username, name };
  if (password) {
    const hashed = await hashNewPassword(password);
    nextUser = { ...nextUser, ...hashed, mustChangePassword: false };
  }
  const database = await openDatabase();
  const transaction = database.transaction("users", "readwrite");
  transaction.objectStore("users").put(nextUser);
  await transactionComplete(transaction);
  publishDataChange();
}

export async function changeOwnPassword(id: string, password: string) {
  const users = await readUsers();
  const user = users.find((entry) => entry.id === id);
  if (!user) throw new Error("الحساب غير موجود");
  await saveUser({ ...user, mustChangePassword: false }, password);
}

export async function deleteUser(id: string) {
  const users = await readUsers();
  const user = users.find((entry) => entry.id === id);
  if (user?.role === "manager" && users.filter((entry) => entry.role === "manager" && entry.active).length <= 1) {
    throw new Error("لا يمكن حذف المدير الوحيد");
  }
  await ensureLocalStore();
  const database = await openDatabase();
  const transaction = database.transaction("users", "readwrite");
  transaction.objectStore("users").delete(id);
  await transactionComplete(transaction);
  publishDataChange();
}

export type NewOrderInput = {
  items: { productId: string; quantity: number }[];
  cashier: RestaurantUser;
  orderType: RestaurantOrder["orderType"];
  tableLabel?: string | null;
  customerName?: string;
  paymentMethod: RestaurantOrder["paymentMethod"];
  discount?: number;
  cashReceived?: number;
  notes?: string;
};

export async function createOrder(input: NewOrderInput): Promise<RestaurantOrder> {
  const [products, settings] = await Promise.all([readAllProducts(), readSettings()]);
  const productById = new Map(products.filter((product) => product.active !== false).map((product) => [product.id, product]));
  const quantities = new Map<string, number>();
  for (const item of input.items) {
    if (!Number.isInteger(item.quantity) || item.quantity < 1 || item.quantity > 99) throw new Error("تحقق من كميات الأصناف");
    if (!productById.has(item.productId)) throw new Error("أحد أصناف الطلب غير متاح");
    quantities.set(item.productId, (quantities.get(item.productId) ?? 0) + item.quantity);
  }
  if (!quantities.size) throw new Error("أضف صنفاً للطلب");
  const items = [...quantities.entries()].map(([productId, quantity]) => {
    const product = productById.get(productId)!;
    return { productId, name: product.name, quantity, unitPrice: product.price, lineTotal: product.price * quantity };
  });
  const subtotal = items.reduce((sum, item) => sum + item.lineTotal, 0);
  const discount = Math.max(0, Math.min(subtotal, Math.floor(Number(input.discount) || 0)));
  const taxable = subtotal - discount;
  const tax = Math.round(taxable * Math.max(0, settings.taxRate) / 100);
  const service = input.orderType === "dine-in" ? Math.round(taxable * Math.max(0, settings.serviceRate) / 100) : 0;
  const deliveryFee = input.orderType === "delivery" ? Math.max(0, Math.floor(settings.deliveryFee)) : 0;
  const total = taxable + tax + service + deliveryFee;
  const cashReceived = input.paymentMethod === "cash" ? Math.floor(Number(input.cashReceived ?? total)) : total;
  if (cashReceived < total) throw new Error("المبلغ المستلم أقل من الصافي");
  const database = await openDatabase();
  const transaction = database.transaction("orders", "readwrite");
  const orderStore = transaction.objectStore("orders");
  let saved: RestaurantOrder | null = null;
  const getAll = orderStore.getAll() as IDBRequest<RestaurantOrder[]>;
  getAll.onsuccess = () => {
    const latest = getAll.result.reduce((maximum, order) => Math.max(maximum, order.sequence || 0), 0);
    const sequence = latest + 1;
    const order: RestaurantOrder = {
      id: sequence,
      sequence,
      receiptNumber: `#${String(sequence).padStart(4, "0")}`,
      cashierId: input.cashier.id,
      cashier: input.cashier.name,
      orderType: input.orderType,
      tableLabel: input.orderType === "dine-in" ? input.tableLabel?.trim() || null : null,
      customerName: input.customerName?.trim() || null,
      paymentMethod: input.paymentMethod,
      subtotal,
      discount,
      tax,
      service,
      deliveryFee,
      total,
      cashReceived,
      changeDue: input.paymentMethod === "cash" ? cashReceived - total : 0,
      notes: input.notes?.trim() ?? "",
      items,
      status: "paid",
      cancelReason: "",
      cancelledBy: "",
      createdAt: new Date().toISOString(),
    };
    saved = order;
    orderStore.put(order);
  };
  await transactionComplete(transaction);
  if (!saved) throw new Error("تعذر حفظ الفاتورة");
  publishDataChange();
  return saved;
}

export async function cancelOrder(id: number, reason: string, manager: RestaurantUser) {
  if (manager.role !== "manager") throw new Error("الإلغاء متاح للمدير فقط");
  if (!reason.trim()) throw new Error("اكتب سبب الإلغاء");
  const database = await openDatabase();
  const transaction = database.transaction(["orders", "audit"], "readwrite");
  const orderStore = transaction.objectStore("orders");
  const get = orderStore.get(id) as IDBRequest<RestaurantOrder | undefined>;
  get.onsuccess = () => {
    if (!get.result) return;
    const order = { ...get.result, status: "cancelled" as const, cancelReason: reason.trim(), cancelledBy: manager.name };
    orderStore.put(order);
    transaction.objectStore("audit").add({ action: "cancel-order", orderId: id, reason: reason.trim(), manager: manager.name, at: new Date().toISOString() });
  };
  await transactionComplete(transaction);
  publishDataChange();
}

export async function addAuditRecord(action: string, details: Record<string, unknown>) {
  const database = await openDatabase();
  const transaction = database.transaction("audit", "readwrite");
  transaction.objectStore("audit").add({ action, ...details, at: new Date().toISOString() });
  await transactionComplete(transaction);
}

export async function exportDataBackup() {
  const snapshot = await readSnapshot();
  const audit = await allFromStore<Record<string, unknown>>("audit");
  return { format: "mazaq-elbalad-backup", version: 1, exportedAt: new Date().toISOString(), ...snapshot, audit };
}

export async function importDataBackup(value: unknown) {
  if (!value || typeof value !== "object" || (value as { format?: string }).format !== "mazaq-elbalad-backup") {
    throw new Error("ملف النسخة الاحتياطية غير صالح");
  }
  const backup = value as Record<string, unknown>;
  const required = ["products", "categories", "tables", "users", "orders"];
  if (required.some((key) => !Array.isArray(backup[key])) || !backup.settings || typeof backup.settings !== "object") {
    throw new Error("بيانات النسخة الاحتياطية غير مكتملة");
  }
  const database = await openDatabase();
  const transaction = database.transaction([...STORE_NAMES], "readwrite");
  for (const name of STORE_NAMES) transaction.objectStore(name).clear();
  for (const name of ["products", "categories", "tables", "users", "orders"] as const) {
    for (const record of backup[name] as object[]) transaction.objectStore(name).put(record);
  }
  transaction.objectStore("settings").put({ ...(backup.settings as object), id: "main" });
  if (Array.isArray(backup.audit)) {
    for (const record of backup.audit) transaction.objectStore("audit").put(record as object);
  }
  await transactionComplete(transaction);
  initializationPromise = Promise.resolve();
  publishDataChange();
}

export async function resetAllData() {
  const database = await openDatabase();
  const transaction = database.transaction([...STORE_NAMES], "readwrite");
  for (const name of STORE_NAMES) transaction.objectStore(name).clear();
  await transactionComplete(transaction);
  initializationPromise = null;
  await ensureLocalStore();
  const cleanup = database.transaction(["orders", "audit"], "readwrite");
  cleanup.objectStore("orders").clear();
  cleanup.objectStore("audit").clear();
  await transactionComplete(cleanup);
  publishDataChange();
}

export async function compressImageFile(file: File, maxSide = 960): Promise<string> {
  if (file.type === "image/svg+xml") {
    const text = await file.text();
    const parsed = new DOMParser().parseFromString(text, "image/svg+xml");
    if (parsed.querySelector("parsererror") || parsed.documentElement.nodeName.toLowerCase() !== "svg") throw new Error("ملف SVG غير صالح");
    parsed.querySelectorAll("script,foreignObject").forEach((node) => node.remove());
    parsed.querySelectorAll("*").forEach((node) => {
      for (const attribute of [...node.attributes]) {
        if (/^on/i.test(attribute.name) || (/^(href|xlink:href)$/i.test(attribute.name) && /^\s*javascript:/i.test(attribute.value))) node.removeAttribute(attribute.name);
      }
    });
    const safeSvg = new XMLSerializer().serializeToString(parsed.documentElement);
    return `data:image/svg+xml;base64,${btoa(unescape(encodeURIComponent(safeSvg)))}`;
  }
  if (!file.type.startsWith("image/")) throw new Error("اختر ملف صورة صالحاً");
  const source = await new Promise<HTMLImageElement>((resolve, reject) => {
    const image = new Image();
    const url = URL.createObjectURL(file);
    image.onload = () => { URL.revokeObjectURL(url); resolve(image); };
    image.onerror = () => { URL.revokeObjectURL(url); reject(new Error("تعذر قراءة الصورة")); };
    image.src = url;
  });
  const ratio = Math.min(1, maxSide / Math.max(source.naturalWidth, source.naturalHeight));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(source.naturalWidth * ratio));
  canvas.height = Math.max(1, Math.round(source.naturalHeight * ratio));
  const context = canvas.getContext("2d");
  if (!context) throw new Error("تعذر ضغط الصورة");
  context.drawImage(source, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL("image/webp", 0.8);
}
